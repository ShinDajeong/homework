package com.ssafy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class BOJ_2206_벽부수고이동하기 {

	static int N, M;
	static int[][] map;
	static int[][][] visited;
	static int[] dx = {-1, 1, 0, 0};
	static int[] dy = {0, 0, -1, 1};
	
	static class Node{
		int x;
		int y;
		int flag;
		public Node(int x, int y, int flag) {
			super();
			this.x = x;
			this.y = y;
			this.flag = flag;
		}
						
	}
	
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());

		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		
		map = new int[N][M];
		visited = new int[N][M][2];
		
		for(int i=0; i<N; i++) {
			String str = br.readLine();
			for(int j=0; j<M; j++) {
				map[i][j] = str.charAt(j) - '0';
			}
		}
		
		
		Queue<Node> q = new LinkedList<Node>();
		q.add(new Node(0,0,0));
		visited[0][0][0] = 1;
		visited[0][0][1] = 1;
		
		while(!q.isEmpty()) {
			Node n = q.poll();
			
			if(n.x == N-1 && n.y == M-1) 
				break;
				
			
			for(int k=0; k<4; k++) {
				int nx = n.x + dx[k];
				int ny = n.y + dy[k];
				
				if(nx < 0 || ny < 0 || nx > N-1 || ny > M-1) continue;
				if(n.flag >= 2) continue;
			
				if(map[nx][ny] == 1) {
					if(n.flag == 0 && visited[nx][ny][1] == 0) {
						visited[nx][ny][1] = visited[n.x][n.y][0] + 1;
						q.add(new Node(nx, ny, 1));
					}
				}
				else {
					if(visited[nx][ny][0] == 0 && n.flag == 0) {
						q.add(new Node(nx, ny, 0));
						visited[nx][ny][0] = visited[n.x][n.y][0] + 1;
					}
					else if(visited[nx][ny][1] == 0 && n.flag == 1){
						q.add(new Node(nx, ny, 1));
						visited[nx][ny][1] = visited[n.x][n.y][1] + 1;
					}
				}
			}
			
		}
		
		if(visited[N-1][M-1][0] == 0 && visited[N-1][M-1][1] == 0) System.out.println(-1);
		else {
			if(visited[N-1][M-1][0] != 0) 
				System.out.println(visited[N-1][M-1][0]);
			else 
				System.out.println(visited[N-1][M-1][1]);
		}
		
	}

}
