package swea;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SW_1952_������ {
	public static void main(String[] args) throws Exception {

		StringBuilder sb = new StringBuilder();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine());
		int[] month = new int[13]; // 1�� ~ 12��
		int[] price = new int[4]; // ����
		int[] dp = new int[13];

		for (int tc = 1; tc <= T; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine(), " ");

			for (int j = 0; j < price.length; j++) {
				price[j] = Integer.parseInt(st.nextToken());
			}

			st = new StringTokenizer(br.readLine(), " ");
			for (int i = 1; i < month.length; i++) {
				month[i] = Integer.parseInt(st.nextToken());
			}

			for (int m = 1; m < 13; m++) {
				if (m >= 3) {
					dp[m] = Math.min(dp[m - 1] + Math.min(month[m] * price[0], price[1]), dp[m-3]+ price[2]);
				} else {
					dp[m] = dp[m - 1] + Math.min(month[m] * price[0], price[1]);
				}
			}

			dp[12] = Math.min(dp[12], price[3]);
			sb.append("#").append(tc).append(" ").append(dp[12]).append('\n');
		} // end test case
		System.out.println(sb);
	} // end main

}
