package com.ssafy;

import java.util.Scanner;

public class BookTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BookMgrImpl bmgr = new BookMgrImpl();
		int menu = -1;
		while(menu != 0) {
			System.out.println("0. 종료\n1. 도서 입력\n2. 전체 도서 정보 출력 \n3. 도서 판매(isbn, 수량입력) \n4. 도서 구매(isbn, 수량입력)");
			menu = sc.nextInt();
			
			switch(menu) {
			case 1 :
				System.out.println("isbn title 금액 수량 입력");
				String isbn = sc.next();
				String title = sc.next();
				int price = sc.nextInt();
				int quantity = sc.nextInt();
				bmgr.add(new Book(isbn, title, price, quantity));
				break;
			case 2 :
				System.out.println(bmgr.search());
				break;
			case 3 :
				System.out.println("도서 판매 : isbn와 quantity 입력");
				String isbn2 = sc.next();
				int quantity2 = sc.nextInt();
				bmgr.sell(isbn2, quantity2);
				break;
			case 4 :
				System.out.println("도서 구매 : isbn와 quantity 입력");
				String isbn3 = sc.next();
				int quantity3 = sc.nextInt();
				bmgr.buy(isbn3, quantity3);
				break;
			}
			
		}
		
	}
}
