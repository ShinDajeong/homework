package com.ssafy;

import java.util.Scanner;

public class BookTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BookMgrImpl bmgr = new BookMgrImpl();
		
		bmgr.add(new Book("isbn1", "title1", 10000, 1));
		System.out.println(bmgr.search());
		bmgr.add(new Book("isbn2", "title2", 10000, 2));
		bmgr.buy("isbn3", 1);
		bmgr.buy("isbn1", 100);
		System.out.println(bmgr.search());
		bmgr.sell("isbn4", 10);
		bmgr.sell("isbn2", 1);
		System.out.println(bmgr.search());
		
	}
}
