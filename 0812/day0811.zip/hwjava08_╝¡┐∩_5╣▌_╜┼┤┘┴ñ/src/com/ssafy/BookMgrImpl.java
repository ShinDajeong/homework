package com.ssafy;

import java.util.ArrayList;
import java.util.List;

public class BookMgrImpl implements IBookMgr {
	private ArrayList<Book> books = new ArrayList<Book>();
	
	@Override
	public void add(Book b) {
		books.add(b);

	}

	@Override
	public List<Book> search() {
		return books;
	}

	@Override
	public void sell(String isbn, int quantity) {
		try {
			for (Book book : books) {
				if(book.getIsbn().equals(isbn)) {
					if(book.getQuantity() - quantity >= 0) {
						book.setQuantity(book.getQuantity() - quantity);
					}
					else {
						throw new QuantityException();
					}
					return;
				}
			}
			throw new ISBNNotFoundException();
			
				
		}catch(ISBNNotFoundException e){
			System.out.println(e.getMessage());
		} catch (QuantityException e) {
			System.out.println(e.getMessage());
		}
		
		
		
		
	
	}

	@Override
	public void buy(String isbn, int quantity) {		
		try {
			for (Book book : books) {
				if(book.getIsbn().equals(isbn)) {
					book.setQuantity(book.getQuantity() + quantity);
					return;
				}
			}
			
			throw new ISBNNotFoundException();
			
		}catch(ISBNNotFoundException e){
			System.out.println(e.getMessage());
		}
		
		
	}

	@Override
	public int getTotalAmount() {
		int total = 0;
		for (Book book : books) {
			total += book.getPrice() * book.getQuantity();
		}
		
		return total;
	}
	
	
	class QuantityException extends Exception{
		QuantityException(){
			super("도서 수량이 부족합니다");
		}
		
	}
	
	class ISBNNotFoundException extends Exception{
		ISBNNotFoundException(){
			super("ISBN이 존재하지 않습니다");
		}
		
		
	
	}
}
