package com.ssafy.shape;

import com.shape.Shape;

public class Rectangle extends Shape{
	
	double width;
	double height;
	
	public Rectangle(double width, double height) {
		super();
		this.width = width;
		this.height = height;
	}

	@Override
	public void calcArea() {
		area = width * height;
	}
	
}
