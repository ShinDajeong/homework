package com.ssafy.shape;

import com.shape.Shape;
import com.shape.ShapeCalculator;

public class RectangleTest {

	public static void main(String[] args) {
		
		Rectangle r = new Rectangle(2, 2);
		ShapeCalculator sc = new ShapeCalculator();
		sc.calculate(r);
	}

}
