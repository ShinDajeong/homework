package com.ssafy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public interface IBookMgr {
	
	// 북 입력 기능
	public abstract void bookAdd(Book book);
	
	// 데이터 전체 검색 기능
	public abstract List<Book> search();
	
	// isbn으로 정보 검색 기능
	public abstract Book search(int isbn);
	
	// title로 정보 검색 
	public abstract List<Book> search(String title);
	
	
	// book만 검색
	public abstract List<Book> searchBook();
	
	// Magazine만 검색
	public abstract List<Magazine> searchMagazine();
	
	// 올해 잡지만 검색하는 기능
	public abstract List<Book> searchMagazineYear();
	
	// 출판사로 검색
	public abstract List<Book> searchPublisher(String publisher);
	
	// 가격으로 검색
	public abstract List<Book> searchPrice(int price);
	
	// 합계
	public abstract int searchSum();
	
	// 평균
	public abstract double searchAvg();
}
