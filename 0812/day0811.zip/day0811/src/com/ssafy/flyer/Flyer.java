package com.ssafy.flyer;

public interface Flyer {
	
	int count = 3;  // 상수
//	public static final int count = 3; // 위와 같음
	// 착륙기능
	public abstract void land();
	
	// 이륙기능
	void takeOff();
//	public abstract void takeOff(); // 위와 같음
	
	
}
