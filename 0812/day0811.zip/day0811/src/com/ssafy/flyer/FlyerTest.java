package com.ssafy.flyer;

public class FlyerTest {

	public static void main(String[] args) {
		
		Bird b = new Bird();
		b.takeOff();
		Airplane a = new Airplane();
		a.takeOff();
		
		Airport ap = new Airport();
		ap.giveToLandPermission(b);
		ap.giveToLandPermission(a);
	}

}
