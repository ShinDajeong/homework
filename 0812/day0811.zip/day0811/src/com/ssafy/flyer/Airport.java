package com.ssafy.flyer;

public class Airport {
	
	public void giveToLandPermission(Flyer f) {
		f.land();
		
	}
	
	
	
}
