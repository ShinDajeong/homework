package cm.ssafy.employee;

import com.ssafy.model.dao.EmployeeDAO;
import com.ssafy.model.vo.Employee;

public class EmployeeDAOTest {

	public static void main(String[] args) {
		EmployeeDAO eDao = new EmployeeDAO();
		
//		eDao.add(new Employee(00001, "직원명1", "직위1", "부서1"));
//		eDao.add(new Employee(00002, "직원명2", "직위2", "부서1"));
//		eDao.add(new Employee(00003, "직원명3", "직위3", "부서2"));
//		eDao.add(new Employee(00004, "직원명4", "직위1", "부서2"));
//		eDao.add(new Employee(00005, "직원명5", "직위2", "부서2"));
		
//		System.out.println("=======모든 직원 출력========");
//		for (Employee e : eDao.search()) {
//			System.out.println(e);
//		}
		
		System.out.println("=======직원 번호로 직원 출력========");
		System.out.println(eDao.search(00006));
		
		System.out.println("=======직원 이름으로 직원 출력========");
		for (Employee e : eDao.search("직원")) {
			System.out.println(e);
		}
		
//		System.out.println("=======수정========");
		eDao.update(00001, "부서2");
		
//		System.out.println("=======삭제========");
		eDao.delete(00005);
		
		System.out.println("=======모든 직원 출력========");
		for (Employee e : eDao.search()) {
			System.out.println(e);
		}
		
	}

}
