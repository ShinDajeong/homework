package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.vo.Employee;
import com.ssafy.util.DBUtil;

public class EmployeeDAO {

	public boolean add(Employee b) {

		String sql = "insert into emp values(?,?,?,?)";

		try (Connection conn = DBUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {

			stmt.setInt(1, b.getEmpNo());
			stmt.setString(2, b.getName());
			stmt.setString(3, b.getPosition());
			stmt.setString(4, b.getDept());
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public List<Employee> search() { // 스탭 1~6까지

		ArrayList<Employee> eList = new ArrayList<>();
		String sql = "select * from emp";

		// 2. Connection
		try (Connection conn = DBUtil.getConnection();
				// 3. Statement Create
				PreparedStatement stmt = conn.prepareStatement(sql);
		// 4. SQL Execute (select)
		) {
			try (ResultSet rs = stmt.executeQuery()) {
				// 5. result
				while (rs.next()) {
					eList.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		return eList;
	}

	public Employee search(int empNo) { // 스탭 1~6까지

		String sql = "select * from emp where empNo = ?";

		try (Connection conn = DBUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			stmt.setInt(1, empNo);
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					return new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		
		return null;
	}
	
	
	public List<Employee> search(String name) { 
		ArrayList<Employee> eList = new ArrayList<>();
		String sql = "select * from emp where name like ?";

		try (Connection conn = DBUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);
		) {
			stmt.setString(1, "%"+name+"%");
			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					eList.add(new Employee(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		return eList;
	}
	
	public boolean update(int empNo, String dept) { 
      	
        String sql =  "update emp set dept = ? where empNo = ?";
         
            try(Connection conn = DBUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ){
            	
            	stmt.setString(1, dept);
            	stmt.setInt(2, empNo);
            	return stmt.executeUpdate()>0;
            } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

        return false;
    }
	
	public boolean delete(int empNo) { 
      	
        String sql =  "delete from emp where empNo = ?";
         
            try(Connection conn = DBUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ){
            	
            	stmt.setInt(1, empNo);
            	return stmt.executeUpdate()>0;
            } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

        return false;
    }

}
