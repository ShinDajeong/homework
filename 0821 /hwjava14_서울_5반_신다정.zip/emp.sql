create table EMP(
	empNo int primary key,
    name varchar(100),
    position varchar(100),
    dept varchar(100)
);

select * from emp;