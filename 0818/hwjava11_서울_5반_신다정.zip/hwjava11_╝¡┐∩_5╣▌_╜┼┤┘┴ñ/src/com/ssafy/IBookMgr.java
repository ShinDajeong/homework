package com.ssafy;

import java.io.IOException;
import java.util.List;

public interface IBookMgr {
	
	public abstract void add(Book b);
	public abstract List<Book> search();
	public abstract void sell(String isbn, int quantity);
	public abstract void buy(String isbn, int quantity);
	public abstract int getTotalAmount();
	public abstract void open() throws IOException;
	public abstract void save();
	public abstract void send();
}
