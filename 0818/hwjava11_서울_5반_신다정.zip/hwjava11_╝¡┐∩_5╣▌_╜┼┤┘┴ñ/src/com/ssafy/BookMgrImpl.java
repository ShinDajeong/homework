package com.ssafy;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class BookMgrImpl implements IBookMgr, Serializable {
	private static ArrayList<Book> books = new ArrayList<Book>();
	String host = "localhost";
	int port = 5100;
	
	@Override
	public void add(Book b) {
		books.add(b);

	}

	@Override
	public List<Book> search() {
		return books;
	}

	@Override
	public void sell(String isbn, int quantity) {
		try {
			for (Book book : books) {
				if(book.getIsbn().equals(isbn)) {
					if(book.getQuantity() - quantity >= 0) {
						book.setQuantity(book.getQuantity() - quantity);
					}
					else {
						throw new QuantityException();
					}
					return;
				}
			}
			throw new ISBNNotFoundException();
			
				
		}catch(ISBNNotFoundException e){
			System.out.println(e.getMessage());
		} catch (QuantityException e) {
			System.out.println(e.getMessage());
		}
		
		
		
		
	
	}

	@Override
	public void buy(String isbn, int quantity) {		
		try {
			for (Book book : books) {
				if(book.getIsbn().equals(isbn)) {
					book.setQuantity(book.getQuantity() + quantity);
					return;
				}
			}
			
			throw new ISBNNotFoundException();
			
		}catch(ISBNNotFoundException e){
			System.out.println(e.getMessage());
		}
		
		
	}

	@Override
	public int getTotalAmount() {
		int total = 0;
		for (Book book : books) {
			total += book.getPrice() * book.getQuantity();
		}
		
		return total;
	}
	
	
	
	@Override
	public void open() {
		try {
			FileInputStream fis = new FileInputStream("C:\\SSAFY/book.dat"); 
			BufferedInputStream bis = new BufferedInputStream(fis); 
			ObjectInputStream in = new ObjectInputStream(bis);
			
			ArrayList<Book> list = (ArrayList<Book>) in.readObject();
			for (Book book : list) {
				books.add(book);
			}
			System.out.println(list);
		}catch(FileNotFoundException e) {
			System.out.println("book.dat 파일 없음");
		}catch(Exception e) {
			e.printStackTrace();
		}
		

		
	}

	@Override
	public void save() {
		try {
			FileOutputStream fos = new FileOutputStream("C:\\SSAFY/book.dat"); 
			BufferedOutputStream bos = new BufferedOutputStream(fos); 
			ObjectOutputStream out = new ObjectOutputStream(bos); 
			out.writeObject(books); 
			out.close(); 
			System.out.println("직렬화 완료");

			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	class QuantityException extends Exception{
		QuantityException(){
			super("도서 수량이 부족합니다");
		}
		
	}
	
	class ISBNNotFoundException extends Exception{
		ISBNNotFoundException(){
			super("ISBN이 존재하지 않습니다");
		}
	}
	
	static class BookClient{
		void run() {
			String host = "localhost";
			int port = 5100;
			
			try ( Socket socket = new Socket(host, port) ) {
				
//				InputStream input = socket.getInputStream();
//	            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
//	 
//	            String message = reader.readLine();
//	            System.out.println(message);
	            
				OutputStream output = socket.getOutputStream();
	            PrintWriter writer = new PrintWriter(output, true);
				for(Book book : books) {
					writer.println(book.toString());
				}
//				 ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
//		            output.writeObject(books);
//		            output.close();
				
			 } catch ( IOException e) {
				 System.out.println("NetworkSimpleClient exception: " + e.getMessage());
				 e.printStackTrace();
			 }
		}
	}
	
	
	@Override
	public void send() {
		BookClient bc = new BookClient();
		bc.run();
	}
	
	
	
	
}


