package com.mycom.myboard.service;

import org.springframework.web.multipart.MultipartFile;

import com.mycom.myboard.dto.BoardDto;
import com.mycom.myboard.dto.BoardParamDto;
import com.mycom.myboard.dto.BoardResultDto;

public interface BoardService {
	
	public BoardResultDto boardDetail(BoardParamDto boardParamDto);
	
	public BoardResultDto boardDelete(int boardId);
	
	public BoardResultDto boardUpdate(BoardDto dto, MultipartFile file);
	
	public BoardResultDto boardInsert(BoardDto dto, MultipartFile file);
	
	
	
	
	
	
	
	
	public BoardResultDto boardList(BoardParamDto boardParamDto);
	//public int boardListTotalCount();	
	public BoardResultDto boardListSearchWord(BoardParamDto boardParamDto);
	//public int boardListSearchWordTotalCount(boardParamDto boardParamDto);
	
	
	// Changes for FileUpload
	
	
	
	
	
	
	
	
	
}
