package com.mycom.myboard.dao;

import com.mycom.myboard.dto.UserDto;

public interface UserDao {
	public int userRegister(UserDto userDto);
}
