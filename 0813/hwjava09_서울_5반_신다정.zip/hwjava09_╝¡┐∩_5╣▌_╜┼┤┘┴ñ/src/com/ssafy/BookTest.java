package com.ssafy;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.NotSerializableException;
import java.util.Scanner;

public class BookTest {
	static BookMgrImpl bmgr = new BookMgrImpl();
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		int menu = -1;
		bmgr.open();
		while(menu != 0) {
			System.out.println("0. 종료\n1. 도서 입력\n2. 전체 도서 정보 출력 \n3. 도서 판매(isbn, 수량입력) \n4. 도서 구매(isbn, 수량입력)");
			menu = sc.nextInt();
			
			switch(menu) {
			case 1 :
				System.out.println("1. Book  2. Magazine");
				int number = sc.nextInt();
				if( number == 1) {
					System.out.println("isbn title 금액 수량 입력");
					String isbn = sc.next();
					String title = sc.next();
					int price = sc.nextInt();
					int quantity = sc.nextInt();
					bmgr.add(new Book(isbn, title, price, quantity));
				}
				else if(number == 2) {
					System.out.println("isbn title 금액 수량 month 입력");
					String isbn = sc.next();
					String title = sc.next();
					int price = sc.nextInt();
					int quantity = sc.nextInt();
					int month = sc.nextInt();
					bmgr.add(new Magazine(isbn, title, price, quantity, month));
				}
				break;
			case 2 :
				for (Book b : bmgr.search()) {
					System.out.println(b);
				}
				break;
			case 3 :
				System.out.println("도서 판매 : isbn와 quantity 입력");
				String isbn2 = sc.next();
				int quantity2 = sc.nextInt();
				bmgr.sell(isbn2, quantity2);
				break;
			case 4 :
				System.out.println("도서 구매 : isbn와 quantity 입력");
				String isbn3 = sc.next();
				int quantity3 = sc.nextInt();
				bmgr.buy(isbn3, quantity3);
				break;
			}
			
		}
		
		bmgr.save();
	}

}
