package com.ssafy.dom;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ssafy.sax.Contact;

public class DOMVOCreateTest {

	public static void main(String[] args) throws Exception {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = factory.newDocumentBuilder();
		Document document = parser.parse("contactlist.xml");
		Element root = document.getDocumentElement();
		
		ArrayList<Contact> list = new ArrayList<Contact>();
		
		NodeList contactList = root.getElementsByTagName("contact");
		for (int i = 0; i < contactList.getLength(); i++) {
			Contact c = new Contact();
			list.add(c);
			
			Element contact = (Element)contactList.item(i);
			NodeList childNodes = contact.getChildNodes();
			System.out.println(childNodes.getLength());
			for (int j = 0; j < childNodes.getLength(); j++) {
				Node node = childNodes.item(j);
				if(node.getNodeType() == Node.ELEMENT_NODE) {

					if(node.getNodeName().equals("name")) {
//						c.setName(node.getFirstChild().getNodeValue());
						c.setName(node.getTextContent());
					}else if(node.getNodeName().equals("phone")) {
//						c.setPhone(node.getFirstChild().getNodeValue());
						c.setPhone(node.getTextContent());
					}else {
//						c.setEmail(node.getFirstChild().getNodeValue());
						c.setEmail(node.getTextContent());
					}
				}
			}
		}
		for (Contact contact : list) {
			System.out.println(contact);
		}
	}

}
