package com.ssafy.news;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ssafy.news.NewsDAOSAXImpl.SAXHandler;



public class NewsDAOSAXImpl implements INewsDAO {

	@Override
	public List<News> getNewsList(String url) throws Exception {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser= factory.newSAXParser();
		SAXHandler handler = new SAXHandler();
		parser.parse(url, handler);
		return handler.getList();
//		return null;
		
	}

	@Override
	public News search(int index) {
		return null;
	}
	
	private void connectNews(String url) throws Exception {
//		SAXParserFactory factory = SAXParserFactory.newInstance();
//		SAXParser parser= factory.newSAXParser();
//		SAXHandler handler = new SAXHandler();
//		parser.parse(url, handler);
//		for (News n : handler.getList()) {
//			System.out.println(n.toString());
//		}
	}
	
	
	static class SAXHandler extends DefaultHandler{
		private ArrayList<News> list;
		private News news;
		private String content;
		
		public ArrayList<News> getList() {
			return list;
		}
		
		@Override
		public void startDocument() throws SAXException {
			list = new ArrayList<News>();
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			if(qName.equals("item")) {
				news = new News();
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			if(news == null) return;
			if(qName.equals("item")) {
                list.add(news);
            } 
            else if(qName.equals("title")) {
                news.setTitle(content);
            }
            else if(qName.equals("description")) {
               news.setDesc(content);
            }
            else if(qName.equals("link")) {
                 news.setLink(content);
            }
		}

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			content =  String.valueOf(ch, start, length);
		}

	}
	
	
	
}
