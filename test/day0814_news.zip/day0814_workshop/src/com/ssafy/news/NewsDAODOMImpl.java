package com.ssafy.news;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class NewsDAODOMImpl implements INewsDAO{
	static List<News> list;
	
	@Override
	public List<News> getNewsList(String url) throws Exception {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder parser = factory.newDocumentBuilder();
		Document document = parser.parse("http://rss.etnews.com/Section902.xml");
		Element root = document.getDocumentElement();
		
		list = new ArrayList<News>();
		NodeList newsList = root.getElementsByTagName("item");
		for (int i = 0; i < newsList.getLength(); i++) {
			News n = new News();
			list.add(n);
			
			Element contact = (Element)newsList.item(i);
//			NodeList childNodes = 
		}
		return null;
		
	}

	@Override
	public News search(int index) {
		// TODO Auto-generated method stub
		return null;
	}

}
