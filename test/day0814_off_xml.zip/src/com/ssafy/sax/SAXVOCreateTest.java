package com.ssafy.sax;

import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXVOCreateTest {

	public static void main(String[] args) 
			throws Exception {
		
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		System.out.println(parser.getClass().getName());
		SAXHandler handler = new SAXHandler();
		parser.parse("contactlist.xml", handler);
		for (Contact c : handler.getList()) {
			System.out.println(c.toString());
		}
	}
	
	static class SAXHandler extends  DefaultHandler{

		private ArrayList<Contact> list;
		private Contact contact;
		private String content;
		
		public ArrayList<Contact> getList() {
			return list;
		}

		@Override
		public void startDocument() throws SAXException {
			list = new ArrayList<Contact>();
		}


		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			if(qName.equals("contact")) {
				contact = new Contact();
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			if(qName.equals("contact")) {
				list.add(contact);
			}else if(qName.equals("name")) {
				contact.setName(content);
			}else if(qName.equals("phone")) {
				contact.setPhone(content);
			}else if(qName.equals("email")) {
				contact.setEmail(content);
			}
		}

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			content = String.valueOf(ch, start, length);
		}
		
	}

}








