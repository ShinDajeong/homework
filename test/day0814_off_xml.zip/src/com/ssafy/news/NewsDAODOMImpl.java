package com.ssafy.news;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NewsDAODOMImpl implements INewsDAO {

	private List<News> list = new ArrayList<News>();
	
	@Override
	public List<News> getNewsList(String url){ // 뉴스 리스트 갖고가기
		list.clear();
		connectNews(url);
		return list;
	}
	@Override
	public News search(int index) { // 뉴스에서 검색
		return list.get(index);
	}
	
	public void connectNews(String url) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = factory.newDocumentBuilder();
			Document document = parser.parse(url);
			Element root = document.getDocumentElement();
			
			NodeList newsList = root.getElementsByTagName("item");
			// System.out.println(contactList.getLength());
			for(int i = 0; i < newsList.getLength(); i++) {
				News w = new News();
				
				Element news = (Element) newsList.item(i);
				
//				news.getElementsByTagName("title").item(0).getTextContent();
//				news.getElementsByTagName("description").item(0).getTextContent();
//				news.getElementsByTagName("link").item(0).getTextContent();
				
				NodeList childNodes = news.getChildNodes();
				// System.out.println(childNodes.getLength());
				for(int j = 0; j < childNodes.getLength(); j ++) {
					Node node = childNodes.item(j);
					if(node.getNodeType() == Node.ELEMENT_NODE) {
						if(node.getNodeName().equals("title")) {
							w.setTitle(node.getTextContent());
						}else if(node.getNodeName().equals("description")) {
							w.setDesc(node.getTextContent());
						}else if(node.getNodeName().equals("link")) {
							w.setLink(node.getTextContent());
						}
					}
				}
				list.add(w);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
