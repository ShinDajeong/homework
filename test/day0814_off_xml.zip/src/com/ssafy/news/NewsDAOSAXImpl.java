package com.ssafy.news;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class NewsDAOSAXImpl implements INewsDAO{
	private List<News> list=new ArrayList<News>();
	@Override
	public List<News> getNewsList(String url) {
		list.clear();
		connectNews(url);
		return list;
	}
	@Override
	public News search(int index) { // 뉴스에서 검색
		return list.get(index);
	}
	private void connectNews(String url){
		
		try{
			SAXParserFactory f=SAXParserFactory.newInstance();
			SAXParser p=f.newSAXParser();	
			p.parse(url, new SAXHandler());
		}catch(Exception e){
			System.out.println(e);
		}
	}	
	private class SAXHandler  extends DefaultHandler{
		String content;
		News n=null;
		
		@Override
		public void startElement(String uri, String localName, String qName,
				Attributes attributes) throws SAXException {
			if(qName.equals("item")){
				n=new News();
			}
		}
		@Override
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			content = String.valueOf(ch, start, length);			
		}
		@Override
		public void endElement(String uri, String localName, String qName)
				throws SAXException {
			if(n!=null){
				switch(qName){
					case "title":
						n.setTitle(content);
						break;
					case "link":
						n.setLink(content);
						break;
					case "description":
						n.setDesc(content);
						break;
					case "item":
						list.add(n);
						n = null;
				}
			}
		}
		
	}
}
