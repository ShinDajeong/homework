package day0722;

import java.util.Scanner;

public class test2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		
		for(int n=1; n<=T; n++) {
			int N = sc.nextInt();
			int[][] arr = new int[N+1][N+1];
			
			int x = sc.nextInt();
			int y = sc.nextInt();
			int j = sc.nextInt();
			
			for(int i=0; i<j; i++) {
				int jx = sc.nextInt();
				int jy = sc.nextInt();
				
				arr[jx][jy] = 1;
			}
			
			int m = sc.nextInt();
			for(int i=0; i<m; i++) {
				int c = sc.nextInt();
				int move = sc.nextInt();
				
				if(c == 1) {
					for(int k=1; k<=move; k++) {
						x--;
						if(x <= 0 || x > N || y <= 0 || y > N || arr[x][y] == 1) {
							x = 0; y = 0;
							break;
						}
					}
					
						
				}
				
				else if(c == 2) {
					for(int k=1; k<=move; k++) {
						y++;
						if(x <= 0 || x > N || y <= 0 || y > N || arr[x][y] == 1) {
							x = 0; y = 0;
							break;
						}
					}
				}
				
				else if(c == 3) {
					for(int k=1; k<=move; k++) {
						x++;
						if(x <= 0 || x > N || y <= 0 || y > N || arr[x][y] == 1) {
							x = 0; y = 0;
							break;
						}
					}
				}
				
				else if(c == 4) {
					for(int k=1; k<=move; k++) {
						y--;
						if(x <= 0 || x > N || y <= 0 || y > N || arr[x][y] == 1) {
							x = 0; y = 0;
							break;
						}
					}
				}
				
			}
			
			
			System.out.println("#" + n + " " + x + " " + y);
		}
		
		
		
		
		
	}

}
