package day0722;

import java.util.Scanner;

public class BuildingTest1 {
	
	static int[][] dir = {
			{-1,-1}, {-1, 0}, {-1, 1},
			{0, -1}, {0, 1},
			{1, -1}, {1, 0}, {1, 1}
	};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for(int testCase=1; testCase<=T; testCase++) {
			int N = sc.nextInt();
			char[][] arr = new char[N][N];
			
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					arr[i][j] = sc.next().charAt(0);
				}
			}
			
			int max = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					int x=0, y=0;
					
					if(arr[i][j] == 'B') {
			
						if(arr[i-1][j-1]=='G' || arr[i-1][j]=='G' || arr[i-1][j+1]=='G'
								|| arr[i][j-1] == 'G' || arr[i][j+1]=='G'
								|| arr[i+1][j-1]=='G' || arr[i+1][j]=='G' || arr[i+1][j+1]=='G') {
							max = (max > 2) ? max : 2;
						}

						else{
							for(int a=0; a<=N; a++) {
								if(arr[a][j] == 'B')
									x++;
							}
							for(int b=0; b<=N; b++) {
								if(arr[i][b] == 'B')
									y++;
							}
							max = (max > (x+y+1)) ? max : x+y-1;
						}
					}

				}
			}
			System.out.println("#" + testCase + " " + max);
		}
		
		
		
	}

}
