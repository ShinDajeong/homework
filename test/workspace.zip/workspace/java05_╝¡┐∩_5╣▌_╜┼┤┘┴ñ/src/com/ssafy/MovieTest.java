package com.ssafy;

import java.util.Scanner;

public class MovieTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		MovieMgr m = MovieMgr.getInstance();
		
		int num = -1;
		
		while(num != 0) {
			System.out.println("<<< 영화 관리 프로그램 >>>");
			System.out.println("1. 영화 정보 입력");
			System.out.println("2. 영화 정보 전체 검색");
			System.out.println("3. 영화명 검색");
			System.out.println("4. 영화 장르별 검색");
			System.out.println("5. 영화 정보 삭제");
			System.out.println("0. 종료");
			System.out.print("원하는 번호를 선택하세요. ");
			num = sc.nextInt();
			
			switch (num) {
			case 1:
				System.out.println("영화제목  영화감독  등급  장르  요약");
				String title = sc.next();
				String director = sc.next();
				int grade = sc.nextInt();
				String genre = sc.next();
				String summary = sc.next();
				Movie movie = new Movie(title, director, grade, genre, summary);
				m.add(movie);
				break;
			case 2:
				for (Movie s : m.search()) {
					System.out.println(s);
				}
				break;
			case 3 :
				String title2 = sc.next();
				for (Movie s : m.search(title2)) {
					System.out.println(s);
				}
				
				break;
			case 4 :
				String director2 = sc.next();
				for (Movie s : m.search(director2)) {
					System.out.println(s);
				}
				
				break;
			case 5 :
				String genre2 = sc.next();
				for (Movie s : m.search(genre2)) {
					System.out.println(s);
				}
				
				break;

			default:
				break;
			}
		}
		
		
	}

}
