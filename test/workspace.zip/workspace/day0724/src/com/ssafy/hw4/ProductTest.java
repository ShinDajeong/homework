package com.ssafy.hw4;

public class ProductTest {

	public static void main(String[] args) {
		// new 생성자호출
		// new Class이름(); -> XXXX
		TV tv = new TV("p01", "좋은 TV", 1000000, 100, 56, "LED");
		
		TV tv2 = new TV("p02", "덜 좋은 TV", 500000, 50, 40);
		TV tv3 = new TV("킹왕짱 TV");
		
//		tv.price = -100000;
		tv.setPrice(5000000); // 값 write
		tv.setInch(60);
		
		tv.setPrice(5000000).setAmount(20);
//		System.out.println(tv.getPrice()); // 값 read
		
		System.out.println(tv);
		System.out.println(tv.toString());
		System.out.println(tv2.toString());		
		System.out.println(tv3.toString());
		
		Store s = Store.getInstance();
		
		TV[] tvs = new TV[3];
		
		tvs[0] = tv;
		tvs[1] = new TV("p03", "삼성 TV2", 2000000, 1, 65, "LED");
		tvs[2] = new TV("삼성 TV3");
		
		for (TV t : tvs) {
			System.out.println(t);
		}
	}

}
