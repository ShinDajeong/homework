package com.mycom.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootVueProjectPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
