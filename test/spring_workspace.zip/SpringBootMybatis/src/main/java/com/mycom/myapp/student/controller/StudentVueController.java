package com.mycom.myapp.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mycom.myapp.student.dto.StudentDto;
import com.mycom.myapp.student.service.StudentService;

@RestController
@RequestMapping(value="/vue")
public class StudentVueController {
	
	@Autowired
	StudentService studentService;
	
	@ExceptionHandler
	public ModelAndView handler(Exception ex) {
		ModelAndView  mav = new ModelAndView("error/errorHandler");
		mav.addObject("msg", ex.getMessage());
		ex.printStackTrace();
		return mav;
	}
	
	@GetMapping(value="/students")
	public ResponseEntity<List<StudentDto>> list() {
		List<StudentDto> list = studentService.list();
		for (StudentDto studentDto : list) {
			System.out.println(studentDto.getStudentId());
			System.out.println(studentDto.getStudentNm());
		}
		//return studentService.list();
		if( list.size() > 0 ) {
			return new ResponseEntity<List<StudentDto>>(list, HttpStatus.OK);
		}else {
			return new ResponseEntity<List<StudentDto>>(list, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(value="/students")
	public ResponseEntity<Integer> insert(@RequestBody StudentDto dto) {
		int n = studentService.insert(dto);
		if( n == 1 ) {
			return new ResponseEntity<Integer>(n, HttpStatus.OK);
		}else {
			return new ResponseEntity<Integer>(n, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping(value="/students/{id}")
	public ResponseEntity<Integer> update(@PathVariable int id, @RequestBody StudentDto dto) {
		int n = studentService.update(dto);
		if( n == 1 ) {
			return new ResponseEntity<Integer>(n, HttpStatus.OK);
		}else {
			return new ResponseEntity<Integer>(n, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping(value="/students/{id}")
	public ResponseEntity<Integer> delete(@PathVariable int id) {
		int n = studentService.delete(id);
		if( n == 1 ) {
			return new ResponseEntity<Integer>(n, HttpStatus.OK);
		}else {
			return new ResponseEntity<Integer>(n, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/students/{id}")
	public ResponseEntity<StudentDto> detail(@PathVariable int id) {
		StudentDto dto = studentService.detail(id);

		if( dto != null ) {
			return new ResponseEntity<StudentDto>(dto, HttpStatus.OK);
		}else {
			return new ResponseEntity<StudentDto>(dto, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
