package com.ssafy;

import java.util.Arrays;
import java.util.Scanner;

public class boj_6603 {
	static int[] arr, numbers;
	static int N;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		N = sc.nextInt();
		
		while(N!=0) {
			numbers = new int[6];
			
			arr = new int[N];
			
			for(int i=0; i<arr.length; i++) {
				arr[i] = sc.nextInt();
			}
			Comb(0, 0);	
			
			N = sc.nextInt();
			System.out.println();
		}
		


	}
	static void Comb(int cnt, int start) {
		if(cnt == 6) {
			for(int i=0; i<numbers.length; i++) {
				System.out.print(numbers[i] + " ");
			}
			System.out.println();
			return;
			
		}
		for(int i=start; i<N; i++) {
			numbers[cnt] = arr[i];
			Comb(cnt+1, i+1);
		}
	}
	

}
