package com.ssafy;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

// 궁사의 위치를 조합으로 바꿔가면서 시뮬레이션을 해야 하는데, 매번 map 의 적 위치를 움직이면서 하게 되면 다시 map을 초기화 해야 함. 
// 따로 적의 위치 및 거리 정보를 자료구조에 관리한다.
// while 문 안에서 한 번씩 궁사가 쏘고 남은 적은 한칸 아래로 내려오도록 구성
// 궁사가 쏘는 단계에서 대상이 되는 적을 매번 구성 후, 우선 순위에 의해 적을 꺼내서 공격  - PriorityQueue 활용
public class BJ_17135_캐슬디펜스 {

	static int Y, X, D, MAX;
    static int[][] map;
    static int[] archers = new int[3];	// 궁수 3자리 (x 좌표)
    
    public static void main(String[] args) throws IOException {
    	
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer tokens = new StringTokenizer(br.readLine());
        
        // 행 - N
        Y = Integer.parseInt(tokens.nextToken());
        // 열 - M
        X = Integer.parseInt(tokens.nextToken());
        // 사정거리 - 공격 거리제한
        D = Integer.parseInt(tokens.nextToken());
        
        // 적군 정보
        map = new int[Y][X];
        for (int y = 0; y < Y; y++) {
            tokens = new StringTokenizer(br.readLine());
            for (int x = 0; x < X; x++) {
                map[y][x] = Integer.parseInt(tokens.nextToken());
            }
        }
        
        // 만약 모든 enemy의 y가  Y가 된다면 방어 실패
        // 0 <= x && x < C인  x에서 3개를 고르는 조합
        // 조합이 완성되면 check() 로 확인
        comb(0, 0);
        System.out.println(MAX);
    }

    private static void check() {
    	
        // 각각의 상황에 맞춰 적군을 복사해서 써야한다.
        List<Enemy> enemies = new ArrayList<>();
        for (int y = 0; y < Y; y++) {
            for (int x = 0; x < X; x++) {
                if (map[y][x] == 1) {
                    enemies.add(new Enemy(y, x));
                }
            }
        }

        // 시뮬레이션 시작
        // 반복문 한번 수행이 한 턴
        // 적군의 r이 R이 되면 종료하고 카운트
        int deadMan = 0;
        while (true) {
        	
            // 궁수가 한 명씩 발사
            for (int i = 0; i < archers.length; i++) {
            	
                // pq에는 각 궁수가 쏠 수 있는 적이 등록됨
            	// 이중 적군 한명만 제거 대상
            	// 꺼낼 때 자동으로 우선순위에 의해 적이 선택됨
                PriorityQueue<Enemy> pqEnemies = new PriorityQueue<>();
                int archer = archers[i];
                for (int e = 0; e < enemies.size(); e++) {
                    Enemy enemy = enemies.get(e);
                    // 턴 마다 새롭게 d 계산
                    enemy.d = Math.abs(archer - enemy.x) + Math.abs(Y - enemy.y);
                    
                    // 사정거리에 있다고 다 죽는 건 아님
                    // 사정거리보다 더 가까워도 살아 남을 수 있음.
                    // 그 모든 대상을 pqEnemies 에 넣는다. 
                    if (enemy.d <= D) {
                        pqEnemies.offer(enemy);
                    }
                }
                // pq 가 비어 있지 않다면 맨 처음 녀석은 사망 표시
                if (!pqEnemies.isEmpty()) {
                    pqEnemies.poll().isTargeted = true;
                }
            }

            // 사망자 정리 및 이동, 종료 체크
//            for (int e = 0; e < enemies.size(); e++) {
//                Enemy enemy = enemies.get(e);
//                if (enemy.isTargeted) {
//                    enemies.remove(e--);	// 하나 지웠다면 인덱스 조절 필요
//                    deadMan++;
//                } else if (enemy.r == R - 1) {//
//                    enemies.remove(e--);	// 끝까지 도달하면 지우고 인덱스 조절
//                } else {
//                    enemy.r++;
//                }
//            }
            
            Iterator<Enemy> iter = enemies.iterator();
            while(iter.hasNext()) {
            	Enemy enemy = iter.next();
            	
            	if (enemy.isTargeted) {			// 사망자 처리
            		iter.remove();
            		deadMan++;
            	} else if (enemy.y == Y - 1) {	// 맨 아래 적 제외
            		iter.remove();
                } else {						// 남은 적 아래로 한 칸 이동
                    enemy.y++;
                }
            }
            
            // 모든 병사가 다 사라지면
            if (enemies.size() == 0) break;
        }
        
        MAX = Math.max(MAX, deadMan);
    }

    public static void comb(int srcIdx, int tgtIdx) {
        if (tgtIdx == 3) {
            check();
            return;
        }
        if (srcIdx == X) {
            return;
        }
        archers[tgtIdx] = srcIdx;

        comb(srcIdx + 1, tgtIdx + 1);	// 선택(O)
        comb(srcIdx + 1, tgtIdx); 		// 선택(X)
    }

    static class Enemy implements Comparable<Enemy> {
        Integer y, x, d;	// d: 궁수와의 거리
        boolean isTargeted;	// 사망 여부

        public Enemy(int y, int x) {
            this.y = y;
            this.x = x;
        }

        @Override
        public String toString() {
            return "[y=" + y + ", x=" + x + ", isDead=" + isTargeted + "]";
        }

        @Override
        public int compareTo(Enemy o) {
            
            if (this.d.equals(o.d)) {		// 거리가 같다면 왼쪽에 있는 적 우선
                return this.x.compareTo(o.x);
            } else {						// 거리가 다르면 오름차순으로 가까운 것부터
                return this.d.compareTo(o.d);
            }
        }

    }

}