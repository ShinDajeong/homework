package com.ssafy;
public class BASIC_Perm {

	static int totalCount = 0;
	static int tgtCount = 3;
	static int[] srcArray = { 1, 2, 3, 4, 5 };
	static int[] tgtArray = new int[tgtCount];
	
	static boolean[] srcUsedArray = new boolean[srcArray.length];
	
	public static void main(String[] args) {
		
		perm(0);
		//permDup(0);
		System.out.println(totalCount);
	}

	public static void perm(int tgtIndex) {
		
		if( tgtIndex == tgtArray.length ) {
			printArray(tgtArray);
			totalCount++;
			return;
		}

		for( int i=0; i<srcArray.length; i++) {

			if( ! srcUsedArray[i] ) {
				
				tgtArray[tgtIndex] = srcArray[i];
				srcUsedArray[i] = true;
				perm(tgtIndex + 1);
				srcUsedArray[i] = false;
			}
		}
	}
	
	public static void permDup(int tgtIndex) {
		
		if( tgtIndex == tgtArray.length ) {
			printArray(tgtArray);
			totalCount++;
			return;
		}

		for( int i=0; i<srcArray.length; i++ ) {

			tgtArray[tgtIndex] = srcArray[i];
			permDup(tgtIndex + 1);
		}
	}
	
	public static void printArray(int[] array) {
		for( int i=0; i<array.length; i++ ) {
			System.out.print(array[i]);
		}
		System.out.println();
	}
}
