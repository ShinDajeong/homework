package com.ssafy;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

// 물이 잠기는 단계
// 	물이 잠기는 단계별로 처리해야 하는데 애매한 표현
// 	물이 잠기는 단계는 <-- 문제에 제시된 NxN 의 높이별이라 함.
// 	물이 잠기는 단계를 중복을 제거하고 자료구조로 관리해야 함, 배열은 불편 자동으로 낮은 것부터 꺼낼 수 있는 PriorityQueue<Integer> 활용
public class BJ_2468_안전영역 {

    static int N;
    static int[][] map;
    static boolean[][] visit;
    
    public static int count = 0;
    public static PriorityQueue<Integer> pqHeight;
    
    // 상 하 좌 우 - 순서 없음.
    public static int[] dy = { -1, 1,  0, 0}; 
    public static int[] dx = {  0, 0, -1, 1};
    
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = null;
        
        N = Integer.parseInt(br.readLine());
        map = new int[N][N];
        pqHeight = new PriorityQueue<>();
        
        pqHeight.offer(0); // 비가 안왔을 경우를 대비해야 한다.
        
        for(int i=0; i < N; i++) {
            st = new StringTokenizer(br.readLine());
            for(int j = 0; j < N; j++) {
                map[i][j] = Integer.parseInt(st.nextToken());
                if(! pqHeight.contains(map[i][j]) ) pqHeight.offer(map[i][j]);
            }
        }
        
        // 물에 잠기는 높이를 하나씩 꺼내서 그 경우마다 계산
        while(!pqHeight.isEmpty()) {
            int h = pqHeight.poll();
            
            visit = new boolean[N][N];
            
            int safeCnt = 0;
            
            for(int i = 0; i < N; i++) {
                for(int j = 0; j < N; j++) {
                    if( map[i][j] > h && !visit[i][j] ) {
                    	safeCnt += 1;
                        dfs( i, j, h);
                    }
                }
            }
            
           count = Math.max(count, safeCnt);
        }
        System.out.println(count);
    }
    
    public static void dfs(int y, int x, int h) {
        visit[y][x] = true;
        
        for(int i = 0; i < 4; i++) {
            int ny = dy[i] + y;
            int nx = dx[i] + x;
            
            if( ny < 0 || nx < 0 || ny >= N || nx >= N || map[ny][nx] <= h || visit[ny][nx] ) continue;
            dfs(ny, nx, h);
        }
    }
}


