package com.ssafy;
public class BASIC_Comb {

	static int totalCount = 0;
	static int tgtCount = 3;
	static int[] srcArray = { 1, 2, 3, 4, 5 };
	static int[] tgtArray = new int[tgtCount];
	
	public static void main(String[] args) {
		comb(0, 0);
		System.out.println(totalCount);
	}
	
	public static void comb(int srcIndex, int tgtIndex) {
		if( tgtIndex == tgtArray.length ) {
			printArray(tgtArray);
			totalCount++;
			return;
		}
		
		if( srcIndex == srcArray.length) return;
		
		tgtArray[tgtIndex] = srcArray[srcIndex];
		comb(srcIndex + 1, tgtIndex + 1);
		comb(srcIndex + 1, tgtIndex);
	}
	
	public static void printArray(int[] array) {
		for( int i=0; i<array.length; i++ ) {
			System.out.print(array[i]);
		}
		System.out.println();
	}
}
