package com.ssafy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class boj_2468 {
	static int N;
	static int[][] arr, map;
	static boolean[][] visited;
	static int[] res;
	static int[] dx = {-1, 1, 0, 0};
	static int[] dy = {0, 0, -1, 1};
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		N = sc.nextInt();
		arr = new int[N][N];
		res = new int[100];
		ArrayList<Integer> list = new ArrayList<>();
		
		int max = 0;
		for(int i=0; i<N; i++) {
			for(int j=0; j<N; j++) {
				arr[i][j] = sc.nextInt();
				if(max < arr[i][j]) max = arr[i][j];
			}
		}
		
		while(max >= 0) {
			map = new int[N][N];
			visited = new boolean[N][N];
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					map[i][j] = (arr[i][j] < max)?1:0;
				}
			}
			
			int cnt = 0;
			for(int i=0; i<N; i++) {
				for(int j=0; j<N; j++) {
					if(map[i][j] == 0 && visited[i][j] == false) {
						dfs(i,j);
						cnt++;
					}
				}
			}
			
			list.add(cnt);
			
			
			max--;
			
		}
		
		Collections.sort(list);
		System.out.println(list.get(list.size()-1));

	}
	
	static void dfs(int i, int j) {
		visited[i][j] = true;
		
		for(int k=0; k<4; k++) {
			int x = i + dx[k];
			int y = j + dy[k];
			
			if(x >= 0 && y >= 0 && x < N && y< N) {
				if(map[x][y] == 0 && visited[x][y] == false) {
					dfs(x,y);
				}
			}

		}
		
	}
	
	
}
