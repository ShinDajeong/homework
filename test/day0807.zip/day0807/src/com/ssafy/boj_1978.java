package com.ssafy;

import java.util.Scanner;

public class boj_1978 {
	static int answer;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int N = sc.nextInt();
		int[] arr = new int[N];
		answer = 0;
		for(int i = 0; i < N; i++) {
			arr[i] = sc.nextInt();
			func(arr[i]);
		}

		System.out.println(answer);
		
	}
	static void func(int a) {
		int cnt = 0;
		for(int i=1; i<=a; i++) {
			if(a%i == 0)
				cnt++;
		}
		if(cnt == 2) answer++;
	}

}
