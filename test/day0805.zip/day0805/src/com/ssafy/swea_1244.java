package com.ssafy;

import java.util.Arrays;
import java.util.Scanner;


public class swea_1244 {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
	
		String s = sc.next();
		int n = sc.nextInt();
		int[] arr = new int[s.length()];
		for(int i=0; i<s.length(); i++) {
			char ch = s.charAt(i);
			arr[i] = ch - '0';
		}
		
		int[] index = arr.clone();
		Arrays.sort(index);
		
		while(n!=0) {
			
			for(int i=0; i<arr.length; i++) {
				if(arr[i] != index[i]) {
					for(int j=0; j<arr.length; j++) {
						if(arr[j] == arr[i]) {
							int idx = j;
						}
							
					}
					
					
				}
			}
			
			
			
			
			n--;
		}
		
		
	}

	

}
