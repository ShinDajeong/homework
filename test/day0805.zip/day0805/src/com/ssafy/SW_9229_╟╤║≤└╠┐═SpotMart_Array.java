package com.ssafy;
import java.util.Scanner;

// 2개 선택이므로 2개의 배열로 계산 가능
// N개 선택일 경우 불가...
public class SW_9229_한빈이와SpotMart_Array {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int t = 1; t <= T; t++) {
			
			int N = sc.nextInt(); // 
			int M = sc.nextInt();
			
			int[] p1 = new int[N];
			int[] p2 = new int[N];

			int max = 0;

			for (int i = 0; i < N; i++) {
				
				p1[i] = sc.nextInt();
				p2[i] = p1[i];
			}
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if( i == j ) continue;
					if( p1[i] + p2[j] <= M && p1[i] + p2[j] > max) max = p1[i] + p2[j];
				}
			}
			
			if( max == 0 ) max = -1;
			System.out.println("#" + t + " " + max);
		}
		
		sc.close();

	}

}

/*
https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AW8Wj7cqbY0DFAXN
*/

/*
4
3 45
20 20 20
6 10
1 2 5 8 9 11
4 100
80 80 60 60
4 20
10 5 10 16

#1 40
#2 10
#3 -1
#4 20
*/