package com.ssafy;
import java.util.Scanner;
import java.io.FileInputStream;
public class swea_1206 {

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T = 10;
		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			int[] arr = new int[1004];
			int cnt = 0;
			for(int i=2; i<N+2; i++) {
				arr[i] = sc.nextInt();
			}
			
			for(int i=2; i<N+2; i++) {
				int num = arr[i];
				while(num != 0) {
					if(arr[i-1] < num && arr[i-2] < num && arr[i+1] < num && arr[i+2] < num )
						cnt++;
					num--;
				}
			}
			
			System.out.println("#"+test_case + " " +cnt);
			
			
		}
		
	}

}
