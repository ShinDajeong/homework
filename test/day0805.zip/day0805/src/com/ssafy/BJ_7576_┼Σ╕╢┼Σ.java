package com.ssafy;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

// 최소값을 같는 것이지만 Queue 를 이용해서 전체를 방문한 dept 중 최대값을 찾는 문제
public class BJ_7576_토마토 {
	
	static class Point{
		int y; 
		int x;
		Point(int y, int x){
			this.y=y;
			this.x=x;
		}
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int M = sc.nextInt();
		int N = sc.nextInt();
		
		int[][] map = new int[N][M];
		
		Queue<Point> queue = new LinkedList<>();
		
		for(int i = 0; i < N; i++) {
			for(int j = 0; j < M; j++) {
				map[i][j] = sc.nextInt();
				
				// 입력 받으면서 바로 최초 토마토는 Queue 에 담는다.
				if(map[i][j] == 1) queue.add(new Point(i,j));
			}
		}
		
		while( !queue.isEmpty()) {
			
			Point p = queue.poll();
			
			int y = p.y;
			int x = p.x;
			
			for(int i = 0; i<dy.length; i++) {
				int ny = y + dy[i];
				int nx = x + dx[i];
				
				// 토마토가 없는 -1 도 경계 안에 포함
				if( ny < 0 || nx < 0 || ny >= map.length || nx >= map[ny].length) continue;
				
				if( map[ny][nx] == 0 ) {
					map[ny][nx] = map[y][x] + 1;
					// 새로 생긴 토마토는 다시 queue에 넣는다.
					queue.add(new Point(ny,nx));
				}
			}
		}
		int max = 0;
		boolean isOk = true;
		for(int i = 0; i < N; i++) {
			for(int j = 0; j < M; j++) {
				if( map[i][j] == 0 ) {
					isOk = false;
				}
				if( max < map[i][j]) max = map[i][j];
			}
		}
		System.out.println( isOk ? max-1 : -1 );
		sc.close();
	}

	//상 하 좌 우 - 우선순위 없음.
	static int[] dy = {-1, 1, 0, 0};
	static int[] dx = { 0, 0,-1, 1};
}

/*
https://www.acmicpc.net/problem/7576
*/
/*
6 4
0 0 0 0 0 0
0 0 0 0 0 0
0 0 0 0 0 0
0 0 0 0 0 1

8



6 4
0 -1 0 0 0 0
-1 0 0 0 0 0
0 0 0 0 0 0
0 0 0 0 0 1

-1



5 5
-1 1 0 0 0
0 -1 -1 -1 0
0 -1 -1 -1 0
0 -1 -1 -1 0
0 0 0 0 0

14

*/