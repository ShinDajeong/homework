package com.ssafy;
import java.util.Scanner;

public class SW_9229_한빈이와SpotMart {

	static int N, M;
	static int[] srcArr, tgtArr;
	static int max;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int t = 1; t <= T; t++) {
			
			N = sc.nextInt(); // 
			M = sc.nextInt();
			
			srcArr = new int[N];
			tgtArr = new int[2];			

			max = 0;

			for (int i = 0; i < N; i++) {				
				srcArr[i] = sc.nextInt();
			}
			
			find(0, 0);
			
			if( max == 0 ) max = -1;
			System.out.println("#" + t + " " + max);
		}
		
		sc.close();

	}

	public static void find(int srcIdx, int tgtIdx) {
		
		if( srcIdx == N ) return;
		
		if( tgtIdx == 2 ) {
			
			//System.out.println(tgtArr[0] + "," + tgtArr[1]);
			if(tgtArr[0] + tgtArr[1] <= M && tgtArr[0] + tgtArr[1] > max)	max = tgtArr[0] + tgtArr[1];
			return;
		}

		tgtArr[tgtIdx] = srcArr[srcIdx];
		
		// 호출 순서 변경 X
		find( srcIdx+1, tgtIdx+1); // 현재 선택이 이어지게 +1 먼저
		find( srcIdx+1, tgtIdx);
		
	}
}

/*
https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AW8Wj7cqbY0DFAXN
*/

/*
4
3 45
20 20 20
6 10
1 2 5 8 9 11
4 100
80 80 60 60
4 20
10 5 10 16

#1 40
#2 10
#3 -1
#4 20
*/