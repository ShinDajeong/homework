package com.ssafy;
import java.util.Scanner;
import java.io.FileInputStream;
public class swea_6730 {

	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			
			int N = sc.nextInt();
			int[] arr = new int[N];
			
			
			for(int i=0; i<N; i++) {
				arr[i] = sc.nextInt();
			}
			
			int down = 0;
			int up = 0;
		
			
			
			for(int i=0; i<arr.length-1; i++) {
				for(int j=i+1; j<i+2; j++) {
					if(arr[i] < arr[j]) {
						up = (arr[j]-arr[i] > up)?arr[j]-arr[i]:up;
					}
					if(arr[i] > arr[j] && arr[i]-arr[j] >0) {
						down = (arr[i]-arr[j] > down)?arr[i]-arr[j]:down;
					}
				}
			}
			
			System.out.println("#"+test_case+ " " +up + " " + down);
			
		}
		
	}

}
