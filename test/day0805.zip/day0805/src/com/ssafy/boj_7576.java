package com.ssafy;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class boj_7576 {
	static int[][] arr;
	static int[][] visited;
	static int N, M, day;
	static Queue<Integer> qx = new LinkedList<>();
	static Queue<Integer> qy = new LinkedList<>();
	// 상, 하, 우, 좌
	static int[] dx = {-1,0,1,0};
	static int[] dy = {0,1,0,-1};
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		M = sc.nextInt();
		N = sc.nextInt();
		arr = new int[N][M];
		visited = new int[N][M];
		
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		
		
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				if(arr[i][j] == 1) {
					qx.offer(i);
					qy.offer(j);
					
				}
			}
		}
		
		bfs();
		
		int max = 0;
		boolean isOk = true;
		for(int i = 0; i < N; i++) {
			for(int j = 0; j < M; j++) {
				if( arr[i][j] == 0 ) {
					isOk = false;
				}
				if( max < arr[i][j]) max = arr[i][j];
			}
		}
		System.out.println( isOk ? max-1 : -1 );
		sc.close();
	}
	
	static void bfs() {
		while(!qx.isEmpty()) {
			int n1 = qx.poll();
			int n2 = qy.poll();
			for(int k=0; k<dx.length; k++) {
				int x = n1+dx[k];
				int y = n2+dy[k];
				
				if(x >=0 && y >= 0 && x<N && y<M && arr[x][y] == 0) {
					arr[x][y] = arr[n1][n2] + 1;
					qx.offer(x);
					qy.offer(y);
				}
			}	
		}
		
	}

}