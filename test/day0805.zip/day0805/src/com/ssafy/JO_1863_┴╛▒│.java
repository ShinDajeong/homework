package com.ssafy;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class JO_1863_종교 {

	static int[] parent;
	
	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		
		int N = Integer.parseInt(st.nextToken()); // 학생수
		int M = Integer.parseInt(st.nextToken()); // 같은 종교 쌍 수
		
		parent = new int[N+1]; // 동일 종교 학생 배열로 동일한 종교은 동일한 번호(parent)를 가진다.
		
		// 자기 자신과 동일하게
		for (int i = 1; i <= N; i++) {
			parent[i] = i;
		}
		
		for (int i = 0; i < M; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			union(a, b);
		}
		
		int cnt = 0;
		for (int i = 1; i <= N; i++) {
			if (parent[i] == i) cnt++;
		}
		System.out.println(cnt);
	}
	
	public static int findSet(int x) {
		// 대표자가 자신이면 자신을 return
		if (x == parent[x])	return x;
		// 아니면 부모로 한번 더 찾는다. 재귀 호출로 최종 부모를 찾게 됨.
		else return parent[x] = findSet(parent[x]);
		
	}

	public static void union(int x, int y) {
		// 두 집합의 대표자를 찾아 합친다.
		x = findSet(x);
		y = findSet(y);
		
		if (x > y)	parent[x] = y; 	// x가 더 크면 x의 부모는 y
		else parent[y] = x;			// y가 더 크면 y의 부모는 x
	}
	
//	// x 학생이 속한 종교 집합 번호 
//	public static int findParent(int x) {
//		// 최초
//		if(parent[x] == x) {
//			return x;
//		} else {
//			int p = findParent(parent[x]);
//			parent[x] = p;
//			return p;
//		}
//	}
//	
//	public static void union(int a, int b) {
//		int pa = findParent(a);
//		int pb = findParent(b);
//		if( pa < pb ) {
//			parent[pb] = pa;
//		}else if( pa > pb ) {
//			parent[pa] = pb;
//		}
//	}
}
