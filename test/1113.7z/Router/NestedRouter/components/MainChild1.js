export default{
    template:`
        <div>
            <p>Vue Nested Router 첫 번째 입니다.</p>
        </div>
    `
}