export default{
    template:`
        <div>
            <p>Vue Nested Router 두번째 입니다.</p>
        </div>
    `
}