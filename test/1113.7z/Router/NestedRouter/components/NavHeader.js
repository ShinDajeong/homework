export default {
  template: `
    <p>
      <router-link to="/">Main</router-link>
      <router-link to="/login">Login</router-link>
    </p>  
  `,
};
