export default {
    template:
    `
    <div>
    <h4>테스트 페이지</h4>
    </div>
    `
};