export default {
    template: `
    <div>
    <h4>Main Component</h4>
    <p>안녕하세요, Vue Router 를 학습하고 있습니다.</p>
    </div>
    `
}