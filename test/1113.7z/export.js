export const MONTH = ['1월', '2월', '3월', '4월', '5월', '6월'];

export const MAX_SIZE = 2000;

export function add(num1, num2){
    return num1 + num2;
}