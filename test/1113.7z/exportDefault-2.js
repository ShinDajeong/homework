
export default {
    template : `<div>My Template</div>`,
    data : {
        num: 20
    },
    func1 : function() {
        console.log("fun1() is called!");
    }
}