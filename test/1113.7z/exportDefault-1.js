
export default {
    template : `<div>template is exported</div>`
};

// export default `<div>template is exported</div>`;