package com.ssafy;
import java.util.Scanner;

public class SW_1873_상호의배틀필드 {

	// delta - 상-하-좌-우
	static int[] dy = { -1, 1,  0, 0 };
	static int[] dx = {  0, 0, -1, 1 };

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int T = sc.nextInt();
		
		for (int t = 1; t <= T; t++) {
			
			// 2차원 배열 -> 배열 세로, 가로 입력
			int H = sc.nextInt();
			int W = sc.nextInt();
			
			// map 생성 ( char type ) 스트링 힙에 공간을 만들기 떄문에 char보다 느리다
			char[][] map = new char[H][W];
			
			
			// 전차 위치 세로, 가로를 배열로
			int[] pos = new int[2];
			
			// map 구성
			// 전차의 위치도 동시에
			for (int i = 0; i < H; i++) {
				
				String c = sc.next();
				
				map[i] = c.toCharArray(); // 문자열을 배열로
				
				for (int j = 0; j < map[i].length; j++) {
					
					switch (map[i][j]) {
						case '<':
						case '>':
						case '^':
						case 'v':
							pos[0] = i;
							pos[1] = j;
							break;
					}
				}
			}

			//명령 문자 갯수
			int N = sc.nextInt();
			//명령 문자 열
			String oper = sc.next();
			
			for (int i = 0; i < N; i++) {
				//명령을 구분하기.
				char c = oper.charAt(i);
				switch (c) {
					case 'U':
						map[pos[0]][pos[1]] = '^';
						move(map, pos, 0); // 0 - delta 상
						break;
					case 'D':
						map[pos[0]][pos[1]] = 'v';
						move(map, pos, 1); // 1 - delta 하
						break;
					case 'L':
						map[pos[0]][pos[1]] = '<';
						move(map, pos, 2); // 2 - delta 좌
						break;
					case 'R':
						map[pos[0]][pos[1]] = '>';
						move(map, pos, 3); // 3 - delta 우
						break;
					case 'S':
						shoot(map, pos);
						break;
				}
			}
			System.out.print("#" + t + " ");

			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++)
					System.out.print(map[i][j]);
				System.out.println();
			}

		}
		
		sc.close();
	}

	static void shoot(char[][] map, int[] pos) {
		int dir = 0;
		//전차의 현재 방향으로 이동방향 설정
		switch (map[pos[0]][pos[1]]) {
			case '^':	//상
				dir = 0;
				break;
			case 'v':	//하
				dir = 1;
				break;
			case '<':	//좌
				dir = 2;
				break;
			case '>':	//우
				dir = 3;
				break;
		}
		
		//대포알 이동 시작 위치  == 전차의 위치		
		int ny = pos[0];
		int nx = pos[1];
		
		// 계속 진행
		while (true) {
			
			// 방향으로 계속 이동.
			ny = ny + dy[dir];
			nx = nx + dx[dir];
			
			//범위를 벗어나면 종료
			if (ny < 0 || nx < 0 || ny >= map.length || nx >= map[0].length) return;
			
			//벽을 만나면 평지로 변경 후 종료
			if (map[ny][nx] == '*') {
				map[ny][nx] = '.';
				return;
			// 강철벽 만나면 그냥 끝
			}else if (map[ny][nx] == '#') {
				return;
			}
				
		}
	}

	static void move(char[][] map, int[] pos, int dir) {
		
		//해 당 방향으로 이동.
		int ny = pos[0] + dy[dir];
		int nx = pos[1] + dx[dir];
		
		//범위를 벗어나면 종료
		if (ny < 0 || nx < 0 || ny >= map.length || nx >= map[0].length) return;
			
		//이동하는 위치가 평지일 때만 
		if (map[ny][nx] == '.') {
			//새 위치에 전차를 이동
			map[ny][nx] = map[pos[0]][pos[1]];
			//원래 전차자리를 평지로 변경
			map[pos[0]][pos[1]] = '.';
			//전차의 위치 갱신
			pos[0] = ny;
			pos[1] = nx;
		}
	}
}
