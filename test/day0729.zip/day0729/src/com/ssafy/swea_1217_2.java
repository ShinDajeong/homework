package com.ssafy;
import java.util.Scanner;
import java.io.FileInputStream;
public class swea_1217_2 {
	
	static int T, N, M, result;
	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		
		for(int i=0; i<10; i++) {
			T = sc.nextInt();
			N = sc.nextInt();
			M = sc.nextInt();
			
			result(T,N,M);
		}
		
	}
	
	private static void result(int T,int N, int M) {
		
		result = 1;
		for(int j=0; j<M; j++) {
			result *= N;
		}
		System.out.println("#" + T + " " + result);
		
	}

	

}
