package com.ssafy;
import java.util.Scanner;
import java.io.FileInputStream;
public class swea_1217 {
	
	static int N, M, answer;
	public static void main(String args[]) throws Exception {
		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		
		for(int i=0; i<10; i++) {
			int T = sc.nextInt();
			N = sc.nextInt();
			M = sc.nextInt();
			
			result(N, M);
		}
		
	}
	
	private static int result(int N, int M) {
		if(M==1) {
			return N; 
		}
		M--;
		return N * result(N, M); 
		
	}

	

}
