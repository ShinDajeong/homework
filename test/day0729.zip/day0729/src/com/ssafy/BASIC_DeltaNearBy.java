package com.ssafy;
import java.util.Scanner;

public class BASIC_DeltaNearBy {

	static char[][] alphabet;
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		alphabet = new char[5][5];
		
		char ch = 'A';
		
		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {
				alphabet[i][j] = ch++;
			}
		}
		
		// 출력으로 확인
		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {
				System.out.print(alphabet[i][j]);				
			}
			System.out.println();
		}

		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {
//				print4NoDelta(i, j);
//				print2H(i,j);
//				print2W(i,j);
//				print4(i, j);
				print8(i, j);
//				print4x(i, j);
//				print8Circle(i, j);
			}
		}
		
		sc.close();
	}
	
	
	static void print4NoDelta(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 4 way neighbors : ");
		
		//상
		int ny = i - 1;
		int nx = j;
		if (ny < alphabet.length && ny >= 0 && nx < alphabet.length && nx >= 0) {
			System.out.print( alphabet[ny][nx] + " ");;
		}
		
		//하
		ny = i + 1;
		nx = j;
		if (ny < alphabet.length && ny >= 0 && nx < alphabet.length && nx >= 0) {
			System.out.print( alphabet[ny][nx] + " ");;
		}
		
		//좌
		ny = i;
		nx = j - 1;
		if (ny < alphabet.length && ny >= 0 && nx < alphabet.length && nx >= 0) {
			System.out.print( alphabet[ny][nx] + " ");;
		}
		
		//우
		ny = i;
		nx = j + 1;
		if (ny < alphabet.length && ny >= 0 && nx < alphabet.length && nx >= 0) {
			System.out.print( alphabet[ny][nx] + " ");;
		}

		System.out.println();
	}
	
	static int dx2h[] = {0, 0};
	static int dy2h[] = {-1, 1};
	
	static void print2H(int i, int j) {
		System.out.print(alphabet[i][j] + " has 2h way neighbors : ");
		
		for(int k=0; k<2; k++) {
			int ny = i + dy2h[k];
			int nx = j + dx2h[k];
			
			if( ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0 )
				continue;
			System.out.print(alphabet[ny][nx]+ " ");
		}
		System.out.println();
	}
	
	static int dx2w[] = {-1, 1};
	static int dy2w[] = {0, 0};
	
	static void print2W(int i, int j) {
		System.out.print(alphabet[i][j] + " has 2w way neighbors : ");
		
		for(int k=0; k<2; k++) {
			int ny = i + dy2w[k];
			int nx = j + dx2w[k];
			
			if(ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0)
				continue;
			System.out.print(alphabet[ny][nx] + " ");
		}
		System.out.println();
	}
	
	static int dx4[] = {0, 1, 0, -1};
	static int dy4[] = {-1, 0, 1, 0};
	
	static void print4(int i, int j) {
		System.out.print(alphabet[i][j] + " has 4 way neighbors : ");
		
		for(int k=0; k<4; k ++) {
			int ny = i + dy4[k];
			int nx = j + dx4[k];
			
			if(ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0)
				continue;
			System.out.print(alphabet[ny][nx] + " ");
		}
		System.out.println();
	}
	
	static int dx8[] = {0, 1, 1, 1, 0, -1, -1, -1};
	static int dy8[] = {-1, -1, 0, 1, 1, 1, 0, -1};
	
	static void print8(int i, int j) {
		System.out.print(alphabet[i][j] + " has 8 way neighbors : ");
		
		for(int k=0; k<8; k++) {
			int ny = i + dy8[k];
			int nx = j + dx8[k];
			
			if(ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0)
				continue;
			System.out.print(alphabet[ny][nx] + " ");
		}
		System.out.println();
		
		
	}
	
	static int dx4x[] = {1, 1, -1, -1 };
	static int dy4x[] = {-1, 1,  1, -1 };
	
	static void print4x(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 4x way neighbors : ");
		
		for (int k = 0; k < 4; k++) {
			int ny = i + dy4x[k];
			int nx = j + dx4x[k];
			if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
				continue;
			}
			System.out.print( alphabet[ny][nx] + " ");
		}
		
		System.out.println();
	}
	
	static int dx8Circle[] = { 0,  1, 1, 1, 0, -1, -1, -1 };
	static int dy8Circle[] = {-1, -1, 0, 1, 1,  1,  0, -1 };
	
	static void print8Circle(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 8 circle way neighbors : ");
		
		for (int k = 0; k < 8; k++) {
			int ny = i + dy8Circle[k];
			int nx = j + dx8Circle[k];
			if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
				continue;
			}
			System.out.print( alphabet[ny][nx] + " ");
		}
		
		System.out.println();
	}
}
