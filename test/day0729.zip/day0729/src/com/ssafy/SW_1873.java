package com.ssafy;
import java.util.Scanner;
import java.io.FileInputStream;
public class SW_1873 {

	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
	
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			
			int H = sc.nextInt();
			int W = sc.nextInt();
			
			char[][] arr = new char[H][W];
			
			int r=0; 
			int c=0;
			
			for(int i=0; i<H; i++) {
				String s = sc.next();
				for(int j=0; j<W; j++) {
					arr[i][j] = s.charAt(j);
					if(arr[i][j] == '>' || arr[i][j] == '<' || arr[i][j] == '^' ||arr[i][j] == 'v' ) {
						r = i;
						c = j;
					}
					
				}
			}
				
			int N = sc.nextInt();
			String s = sc.next();
			for(int i=0; i<N; i++) {
				char ch = s.charAt(i);
				if(ch == 'U') {
					arr[r][c] = '^';
					if(r-1 >= 0 && arr[r-1][c] == '.') {
						arr[r][c] = '.';
						r = r-1;
						arr[r][c] = '^';
					}
				}
				else if(ch == 'D') {
					arr[r][c] = 'v';
					if(r+1 < H && arr[r+1][c] == '.') {
						arr[r][c] = '.';
						r = r+1;
						arr[r][c] = 'v';
					}
				}
				else if(ch == 'L') {
					arr[r][c] = '<';
					if(c-1 >=0 && arr[r][c-1] == '.') {
						arr[r][c] = '.';
						c = c-1;
						arr[r][c] = '<';
						
					}
				}
				else if(ch == 'R') {
					arr[r][c] = '>';

					if(c+1 < W && arr[r][c+1] == '.') {
						arr[r][c] = '.';
						c = c+1;
						arr[r][c] = '>';
						
					}
				}
				else if(ch == 'S') {
					switch (arr[r][c]) {
					case '>':
						for(int k=c+1; k<W; k++) {
							if(arr[r][k] == '#' || c+1 >= W)
								break;
							if(arr[r][k] == '*') {
								arr[r][k] = '.';
								
								break;
							}
						}
						break;
					case '<':
						for(int k=c-1; k>=0; k--) {
							if(arr[r][k] == '#'|| c-1 <0)
								break;
							if(arr[r][k] == '*') {
								arr[r][k] = '.';
									
								break;
							}
						}
						break;
					case '^':
						for(int k=r-1; k>=0; k--) {
							if(arr[k][c] == '#' || r-1 < 0)
								break;
							if(arr[k][c] == '*') {
								arr[k][c] = '.';
								
								break;
							}
						}
						break;
					case 'v':
						for(int k=r+1; k<H; k++) {
							if(arr[k][c] == '#' || r+1 >= H)
								break;
							if(arr[k][c] == '*') {
								arr[k][c] = '.';
								
								break;
							}
						}
						break;

					}
					
				}
				
			}
		
			System.out.print("#"+test_case+" ");
			for(int i=0; i<H; i++) {
				for(int j=0; j<W; j++) {
					System.out.print(arr[i][j]);
				}
				System.out.println();
			}
		
			
			
		}

	}
}