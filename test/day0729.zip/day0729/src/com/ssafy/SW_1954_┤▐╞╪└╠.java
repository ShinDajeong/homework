package com.ssafy;
import java.util.Scanner;

public class SW_1954_달팽이 {

	static int T;
	static int N;
	static int [][] snail;
	
	// 우 - 하 - 좌 - 상
	static int[] dy = {0, 1, 0,-1}; 
	static int[] dx = {1, 0,-1, 0};
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		T = sc.nextInt();
		
		for (int t = 1; t <= T; t++) {
			
			N = sc.nextInt();
			snail = new int[N][N];
			
			int y = 0;
			int x = 0;
			int d = 0;
			
//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < N; j++) {
//					
//					snail[y][x] = i*N+j+1;
//					
//					// 각 현재 진행방향에 따라 조건에 맞지 않으면 다음 조건으로 변경 d = ?
//					// 방향을 변경할 조건이 아니면 같은 방향으로 계속 진행
//					
//					if(d == 0){ // 우
//						if( x + dx[d] >= N || snail[y][x + dx[d]] != 0 ){
//							d = 1; // 하
//						}
//					}else if(d == 1){ // 하
//						if(y + dy[d] >= N || snail[y + dy[d]][x] != 0 ){
//							d = 2; // 좌
//						}
//					}else if(d == 2){ // 좌
//						if( x + dx[d] < 0 || snail[y][x + dx[d]] != 0 ){
//							d = 3; // 상 
//						}
//					}else if(d == 3){ // 상
//						if( y + dy[d] < 0 || snail[y + dy[d]][x] != 0 ){
//							d = 0; // 우
//						}
//					}
//					
//					x += dx[d];
//					y += dy[d];
//				}
//			}
			
			int cnt = 1;
			while(cnt <= N*N) {
				snail[y][x] = cnt;
				cnt++;
				// 각 현재 진행방향에 따라 조건에 맞지 않으면 다음 조건으로 변경 d = ?
				// 방향을 변경할 조건이 아니면 같은 방향으로 계속 진행
				
				if(d == 0){ // 우
					if( x + dx[d] >= N || snail[y][x + dx[d]] != 0 ){
						d = 1; // 하
					}
				}else if(d == 1){ // 하
					if(y + dy[d] >= N || snail[y + dy[d]][x] != 0 ){
						d = 2; // 좌
					}
				}else if(d == 2){ // 좌
					if( x + dx[d] < 0 || snail[y][x + dx[d]] != 0 ){
						d = 3; // 상 
					}
				}else if(d == 3){ // 상
					if( y + dy[d] < 0 || snail[y + dy[d]][x] != 0 ){
						d = 0; // 우
					}
				}
				
				x += dx[d];
				y += dy[d];
			}
			
			
			// 출력 양식 주의
			System.out.println("#" + t);
			for (int i = 0; i <N; i++) {
				for (int j = 0; j <N; j++) {
					System.out.print(snail[i][j] + " ");
				}
				System.out.println();
			}
		}
		
		sc.close();
	}
}

/*
https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV5PobmqAPoDFAUq
*/

/*
출력시 각 테스트케이스 사이 빈칸 없도록!!
*/


/*
10
1
2
3
4
5
6
7
8
9
10


#1
1 
#2
1 2 
4 3 
#3
1 2 3 
8 9 4 
7 6 5 
#4
1 2 3 4 
12 13 14 5 
11 16 15 6 
10 9 8 7 
#5
1 2 3 4 5 
16 17 18 19 6 
15 24 25 20 7 
14 23 22 21 8 
13 12 11 10 9 
#6
1 2 3 4 5 6 
20 21 22 23 24 7 
19 32 33 34 25 8 
18 31 36 35 26 9 
17 30 29 28 27 10 
16 15 14 13 12 11 
#7
1 2 3 4 5 6 7 
24 25 26 27 28 29 8 
23 40 41 42 43 30 9 
22 39 48 49 44 31 10 
21 38 47 46 45 32 11 
20 37 36 35 34 33 12 
19 18 17 16 15 14 13 
#8
1 2 3 4 5 6 7 8 
28 29 30 31 32 33 34 9 
27 48 49 50 51 52 35 10 
26 47 60 61 62 53 36 11 
25 46 59 64 63 54 37 12 
24 45 58 57 56 55 38 13 
23 44 43 42 41 40 39 14 
22 21 20 19 18 17 16 15 
#9
1 2 3 4 5 6 7 8 9 
32 33 34 35 36 37 38 39 10 
31 56 57 58 59 60 61 40 11 
30 55 72 73 74 75 62 41 12 
29 54 71 80 81 76 63 42 13 
28 53 70 79 78 77 64 43 14 
27 52 69 68 67 66 65 44 15 
26 51 50 49 48 47 46 45 16 
25 24 23 22 21 20 19 18 17 
#10
1 2 3 4 5 6 7 8 9 10 
36 37 38 39 40 41 42 43 44 11 
35 64 65 66 67 68 69 70 45 12 
34 63 84 85 86 87 88 71 46 13 
33 62 83 96 97 98 89 72 47 14 
32 61 82 95 100 99 90 73 48 15 
31 60 81 94 93 92 91 74 49 16 
30 59 80 79 78 77 76 75 50 17 
29 58 57 56 55 54 53 52 51 18 
28 27 26 25 24 23 22 21 20 19 

*/
