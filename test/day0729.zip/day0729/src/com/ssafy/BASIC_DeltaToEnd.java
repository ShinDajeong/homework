package com.ssafy;
import java.util.Scanner;

public class BASIC_DeltaToEnd {

	static char[][] alphabet;
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		alphabet = new char[5][5];
		
		char ch = 'A';
		
		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {
				alphabet[i][j] = ch++;
			}
		}
		
		// 출력으로 확인
		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {
				System.out.print(alphabet[i][j]);				
			}
			System.out.println();
		}

		for(int i=0; i<alphabet.length; i++) {
			for(int j=0; j<alphabet.length; j++) {

//				print2HToEnd(i,j);
//				print2WToEnd(i,j);
//				print4ToEnd(i, j);
				//print8ToEnd(i, j);
				print4xToEnd(i, j);
//				print8CircleToEnd(i, j);
			}
		}
		
		sc.close();
	}
	

	static int dx2h[] = {  0, 0 };
	static int dy2h[] = { -1, 1 };
	
	static void print2HToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 2h way neighbors to end : ");
		
		for (int k = 0; k < 2; k++) {
			
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy2h[k];
				nx = nx + dx2h[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
	
	static int dx2w[] = { -1, 1 };
	static int dy2w[] = {  0, 0 };
	
	static void print2WToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 2w way neighbors to end  : ");
		
		for (int k = 0; k < 2; k++) {
			
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy2w[k];
				nx = nx + dx2w[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
	
	static int dx4[] = { 0, 1, 0, -1 };
	static int dy4[] = {-1, 0, 1,  0 };
	
	static void print4ToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 4 way neighbors to end  : ");
		
		for (int k = 0; k < 4; k++) {
			
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy4[k];
				nx = nx + dx4[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
	
	static int dx8[] = { 0, 1, 0, -1,  1, 1, -1, -1 };
	static int dy8[] = {-1, 0, 1,  0, -1, 1,  1, -1 };
	
	static void print8ToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 8 way neighbors to end  : ");
		
		for (int k = 0; k < 8; k++) {
			
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy8[k];
				nx = nx + dx8[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
	
	static int dx4x[] = {1, 1, -1, -1 };
	static int dy4x[] = {-1, 1,  1, -1 };
	
	static void print4xToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 4x way neighbors to end  : ");
		
		for (int k = 0; k < 4; k++) {
			
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy4x[k];
				nx = nx + dx4x[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
	
	static int dx8Circle[] = { 0,  1, 1, 1, 0, -1, -1, -1 };
	static int dy8Circle[] = {-1, -1, 0, 1, 1,  1,  0, -1 };
	
	static void print8CircleToEnd(int i, int j) {
		
		System.out.print(alphabet[i][j] + " has 8 circle way neighbors to end  : ");
		
		for (int k = 0; k < 8; k++) {
			int ny = i;
			int nx = j;
			
			while (true) {
				ny = ny + dy8Circle[k];
				nx = nx + dx8Circle[k];
				
				if (ny >= alphabet.length || ny < 0 || nx >= alphabet.length || nx < 0) {
					break;
				}
				System.out.print( alphabet[ny][nx] + " ");
			}
			System.out.print("-");
		}
		
		System.out.println();
	}
}
