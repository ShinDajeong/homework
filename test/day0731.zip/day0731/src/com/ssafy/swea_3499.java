package com.ssafy;

import java.util.Arrays;
import java.util.Scanner;

public class swea_3499 {
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
			int N = sc.nextInt();
			StringBuilder sb = new StringBuilder();
			sc.nextLine();
			String str = sc.nextLine();
			String[] arr = str.split(" ");
			
			if(N%2==0) {
				int num = N/2;
				for(int i=0; i<N/2; i++) {
					sb.append(arr[i] + " ");
					sb.append(arr[num+i] + " ");
				}
			}
			else {
				int num = N/2+1;
				int cnt = 0;
				for(int i=0; i<num; i++) {
					sb.append(arr[i] + " ");
					if(cnt != num-1) {
						sb.append(arr[num+i] + " ");
						cnt++;
					}
				}
			}

			System.out.println("#"+test_case + " " + sb);
			
		}
	}
	
}
