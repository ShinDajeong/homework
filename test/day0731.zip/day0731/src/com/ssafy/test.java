package com.ssafy;

import java.util.Stack;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Character> stack = new Stack<Character>();
		stack.push('0');
		
	}

}
