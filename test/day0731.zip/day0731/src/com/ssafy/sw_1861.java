package com.ssafy;
import java.util.Arrays;
import java.util.Scanner;
import java.io.FileInputStream;
public class sw_1861 {
	// 상 우 하 좌
	static int dx[] = {-1, 0, 1, 0};
	static int dy[] = {0, 1, 0, -1};
	static boolean visited[];
	static int [][] arr = new int[1000][1000];
	static int [][] result = new int[1000][1000];
	static int N;
	public static void main(String args[]) throws Exception {
//		System.setIn(new FileInputStream("input.txt"));
		Scanner sc = new Scanner(System.in);
		int T;
		T=sc.nextInt();
		
		
		for(int test_case = 1; test_case <= T; test_case++)
		{
		
			N = sc.nextInt();

			for(int i=0; i<arr.length; i++) {
				for(int j=0; j<arr[i].length; j++) {
					arr[i][j] = sc.nextInt();
				}
			}
			
			for(int i=0; i<arr.length; i++) {
				for(int j=0; j<arr[i].length; j++) {
					function(i,j);
				}
			}		
			
			
			
		}

	}
	
	private static void function(int i, int j) {
		
		for(int k=0; k<4; k++) {
			if(arr[i+dx[k]][j+dy[k]]-arr[i][j] == 1) {
				function(i+dx[k], j+dx[k]);
			}
		}
		
		
	}
	
	
	
	
}
