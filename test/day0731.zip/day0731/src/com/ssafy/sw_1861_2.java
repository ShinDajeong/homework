package com.ssafy;

public class sw_1861_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
