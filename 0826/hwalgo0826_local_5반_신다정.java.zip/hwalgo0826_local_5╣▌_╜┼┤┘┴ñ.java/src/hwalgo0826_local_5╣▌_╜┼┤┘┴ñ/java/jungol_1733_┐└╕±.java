package hwalgo0826_local_5반_신다정.java;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class jungol_1733_오목 {

	static int[][] map;
	static int[][] visited;
	static int[] dx = {-1, 1, 0, 0, -1, 1, -1, 1};
	static int[] dy = {0, 0, -1, 1, -1, 1, 1, -1};
	
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		map = new int[19][19];
		visited = new int[19][19];
		
		for(int i=0; i<19; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			for(int j=0; j<19; j++) {
				map[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		
		
		int sum_b = 0;
		int sum_w = 0;
		int result_x_b = 0;
		int result_y_b = 0;
		int result_x_w = 0;
		int result_y_w = 0;
		for(int i=0; i<19; i++) {
			for(int j=0; j<19; j++) {
				if(map[i][j] == 1) {
					int a = black(i,j);
					System.out.println(a);
					if(sum_b < a) {
						sum_b = a;
						result_x_b = i;
						result_y_b = j;
					}
					
				}
				else if(map[i][j] == 2) {
					int b = white(i,j);
					if(sum_w <b) {
						sum_w = b;
						result_x_w = i;
						result_y_w = j;
					}
				}

				for (int[] a : visited) {
					Arrays.fill(a, 0);
				}
			}
		}

		if(sum_b > sum_w && sum_b == 5) {
			System.out.println("1");
			result_x_b++;
			result_y_b++;
			System.out.println(result_x_b + " " + result_y_b);
		}
		else if(sum_b < sum_w && sum_w == 5) {
			System.out.println("2");
			result_x_w++;
			result_y_w++;
			System.out.println(result_x_w + " " + result_y_w);
		}
		else {
			System.out.println("0");
		}
	}

	static int black(int x, int y) {
		
		int cnt = 0;
		int max = 0;
		visited[x][y] = 1;
		cnt++;
		
		
		for(int k=0; k<8; k++) {
			int nx = x + dx[k];
			int ny = y + dy[k];
			
			if(nx < 0 || ny < 0 || nx > 18 || ny > 18) continue;
			
			while(true) {
				
				if(nx >= 0 && ny >= 0 && nx <= 18 && ny <= 18 && map[nx][ny] == 1 && visited[nx][ny] == 0) {
					cnt++;
					visited[nx][ny] = 1;
					nx += dx[k];
					ny += dy[k];
					
				}
				else {
					max = (max >cnt)?max:cnt;
					break;
				}
			}
			
			cnt = 1;
		}
		
		
		
		return max;
	}
	
	static int white(int x, int y) {
		
		int cnt = 0;
		int max = 0;
		visited[x][y] = 2;
		cnt++;
		
		
		for(int k=0; k<8; k++) {
			int nx = x + dx[k];
			int ny = y + dy[k];
			
			if(nx < 0 || ny < 0 || nx > 18 || ny > 18) continue;
			
			while(true) {
			
				if(nx >= 0 && ny >= 0 && nx <= 18 && ny <= 18 && map[nx][ny] == 2 && visited[nx][ny] == 0) {
					cnt++;
					visited[nx][ny] = 2;
					nx += dx[k];
					ny += dy[k];
					
				}
				else {
					max = (max >cnt)?max:cnt;
					break;
				}
			}
			cnt = 1;
		}
		
		return max;
	}
	
}
