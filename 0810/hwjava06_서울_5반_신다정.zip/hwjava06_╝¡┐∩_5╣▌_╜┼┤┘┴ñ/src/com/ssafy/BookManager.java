package com.ssafy;

import java.util.Arrays;

public class BookManager {
	Book[] books = new Book[100];
	int index;
	
	public int getSize() {
		return index;
	}
	
	// 북 입력 기능
	public void bookAdd(Book b) {
		books[index++] = b;
	}
	
	// 매거진 입력 기능
	public void magazineAdd(Magazine m) {
		books[index++] = m;
	}
	
	// 데이터 전체 검색 기능
	public Book[] search() {
		Book[] b = new Book[index];
		for(int i=0; i<index; i++) {
				b[i] = books[i];
		}
		return b;
	}
	
	// isbn으로 정보 검색 기능
	public Book[] search(int isbn) {
		Book[] b = new Book[index];
		
		int cnt = 0;
		for(int i=0; i<index; i++) {
			if(books[i].getIsbn() == isbn) {
				b[cnt++] = books[i];
			}
		}

		return Arrays.copyOfRange(b, 0, cnt);
		
	}
	
	// title로 정보 검색 
	public Book[] search(String title) {
		Book[] b = new Book[index];
		
		int cnt = 0;
		for(int i=0; i<index; i++) {
			if(books[i].getTitle().contains(title)) {
				b[cnt++] = books[i];
			}
		}
		return Arrays.copyOfRange(b, 0, cnt);
	}
	
	// book만 검색
	public Book[] searchBook() {
		Book[] b = new Book[index];
		
		int cnt = 0;
		for(int i=0; i<index; i++) {
			if(books[i] instanceof Magazine) continue;
			else b[cnt++] = books[i];
		}
		return Arrays.copyOfRange(b, 0, cnt);
	}
	
	// Magazine만 검색
	public Book[] searchMagazine() {
		Book[] b = new Book[index];
		
		int cnt = 0;
		for(int i=0; i<index; i++) {
			if(books[i] instanceof Magazine == false) continue;
			else b[cnt++] = books[i];
		}
		return Arrays.copyOfRange(b, 0, cnt);
	}
	
	
	// 출판사로 검색
	public Book[] searchPublisher(String publisher) {
		Book[] b = new Book[index];
		
		int cnt = 0;
		
		for(int i=0; i<index; i++) {
			if(books[i].getPublisher().contains(publisher)) {
				b[cnt++] = books[i];
			}
		}
		return Arrays.copyOfRange(b, 0, cnt);
	}
	
	public Book[] searchPrice(int price) {
		Book[] b = new Book[index];
		
		int cnt = 0;
		
		for(int i=0; i<index; i++) {
			if(books[i].getPrice() < price) {
				b[cnt++] = books[i];
			}
		}
		return Arrays.copyOfRange(b, 0, cnt);
	}
	
	public int searchSum() {
		Book[] b = new Book[index];
		
		int sum = 0;
		for(int i=0; i<index; i++) {
			sum += books[i].getPrice();
		}
		return sum;
	}
	
	public int searchAvg() {
		Book[] b = new Book[index];
		
		int sum = searchSum();
		int avg = sum / index;
		
		return avg;
	}
	
	
}
