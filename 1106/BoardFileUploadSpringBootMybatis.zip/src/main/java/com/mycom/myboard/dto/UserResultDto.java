package com.mycom.myboard.dto;

public class UserResultDto {

	private int result;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

}
