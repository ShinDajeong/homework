package com.mycom.myboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardFileUploadSpringBootMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardFileUploadSpringBootMybatisApplication.class, args);
	}

}
