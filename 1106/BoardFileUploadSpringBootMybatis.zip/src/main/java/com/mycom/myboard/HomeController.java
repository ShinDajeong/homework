package com.mycom.myboard;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping(value = {"/", "/board"})
	private String Home() {
		return ("board/boardMain");
	}
	
	@GetMapping("/login")
	private String Login() {
		return ("login");
	}
}
