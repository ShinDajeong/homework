package com.ssafy;

import java.util.Scanner;

public class BookTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BookMgrImpl bmgr = new BookMgrImpl();
		int menu = -1;
		while(menu != 0) {
			System.out.println("0. 종료\n1. 데이터 입력 기능 \n2. 데이터 전체 검색 기능 \n3. isbn으로 정보를 검색하는 기능\n"
					+"4. title로 정보를 검색하는 기능(제목을 포함한 모든 정보) \n5. book만 검색하는 기능 \n6. Magazine만 검색하는 기능\n"
					+ "7. 올해 잡지만 검색하는 기능\n8. 출판사로 검색하는 기능 \n9. 가격으로 검색 기능(주어진 가격보다 낮은) \n"
					+ "10. 저장된 모든 도서의 금액 합계를 구하는 기능 \n11. 저장된 모든 도서 금액 평균을 구하는 기능");
			menu = sc.nextInt();
			
			switch (menu) {
			case 1:
				System.out.println("1. 책 입력  2. 매거진 입력");
				int s = sc.nextInt();
				if(s == 1) {
					System.out.println("(띄어쓰기로 구분)책 입력 : isbn title author publisher price desc");
					int isbn = sc.nextInt();
					String title = sc.next();
					String author = sc.next();
					String publisher = sc.next();
					int price = sc.nextInt();
					String desc = sc.next();
					bmgr.bookAdd(new Book(isbn, title, author, publisher, price, desc));
					
				}
				if(s == 2) {
					System.out.println("(띄어쓰기로 구분)매거진 입력  : isbn title author publisher price desc year month");
					int isbn = sc.nextInt();
					String title = sc.next();
					String author = sc.next();
					String publisher = sc.next();
					int price = sc.nextInt();
					String desc = sc.next();
					int year = sc.nextInt();
					int month = sc.nextInt();
					bmgr.magazineAdd(new Magazine(isbn, title, author, publisher, price, desc, year, month));
				}
				
				break;
			case 2:
				System.out.println("전체 출력");
				for (Book b : bmgr.search()) {
					System.out.println(b);
				}
				break;
			case 3:
				System.out.println("isbn 입력");
				int isbn = sc.nextInt();
				for (Book b : bmgr.search(isbn)) {
					System.out.println(b);
				}
				break;
			case 4:
				sc.nextLine();
				System.out.println("title 입력");
				String title = sc.nextLine();
				for (Book b : bmgr.search(title)) {
					System.out.println(b);
				}
				break;
			case 5:
				System.out.println("Book만 검색");
				for (Book b : bmgr.searchBook()) {
					System.out.println(b);
				}
				break;
			case 6:
				System.out.println("Magazine만 검색");
				for (Book b : bmgr.searchMagazine()) {
					System.out.println(b);
				}
				break;
			case 7:
				System.out.println("올해 Magazine만 검색");
				for (Book b : bmgr.searchMagazineYear()) {
					System.out.println(b);
				}
				break;
			case 8:
				sc.nextLine();
				System.out.println("출판사 입력");
				String publisher = sc.nextLine();
				for (Book b : bmgr.searchPublisher(publisher)) {
					System.out.println(b);
				}
				break;
			case 9:
				System.out.println("가격 입력");
				int price = sc.nextInt();
				for (Book b : bmgr.searchPrice(price)) {
					System.out.println(b);
				}
				break;
			case 10:
				System.out.println("저장된 모든 도서의 금액 합계를 구하는 기능");
				System.out.println(bmgr.searchSum());
				break;
			case 11:
				System.out.println("저장된 모든 도서의 금액 평균을 구하는 기능");
				System.out.println(bmgr.searchAvg());
				break;
			
			default:
				break;
			}
		}
		
		
		
		
		
	}
}
