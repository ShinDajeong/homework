package com.ssafy;

import java.util.ArrayList;

public class BookMgrImpl implements IBookMgr{
	private ArrayList<Book> books = new ArrayList<Book>();

	@Override
	public void bookAdd(Book b) {
		books.add(b);
		
	}

	@Override
	public void magazineAdd(Magazine m) {
		books.add(m);
		
	}

	@Override
	public ArrayList<Book> search() {
		return books;
	}

	@Override
	public ArrayList<Book> search(int isbn) {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).getIsbn() == isbn)
				b.add(books.get(i));
		}
		
		return b;
	}

	@Override
	public ArrayList<Book> search(String title) {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).getTitle().contains(title))
				b.add(books.get(i));
		}
		
		return b;
	}

	@Override
	public ArrayList<Book> searchBook() {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i) instanceof Magazine == false) {
				b.add(books.get(i));
			}
		}
		
		return b;
	}

	@Override
	public ArrayList<Book> searchMagazine() {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i) instanceof Magazine) {
				b.add(books.get(i));
			}
		}
		
		return b;
	}
	@Override
	public ArrayList<Book> searchMagazineYear() {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i) instanceof Magazine) {
				if(((Magazine)books.get(i)).getYear() == 2020)
					b.add(books.get(i));
			}
		}
		
		return b;
	}
	@Override
	public ArrayList<Book> searchPublisher(String publisher) {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).getPublisher().equals(publisher))
				b.add(books.get(i));
		}
		
		return b;
	}

	@Override
	public ArrayList<Book> searchPrice(int price) {
		ArrayList<Book> b = new ArrayList<Book>();
		
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).getPrice() < price)
				b.add(books.get(i));
		}
		
		return b;
	}

	@Override
	public int searchSum() {
		int sum = 0;
		for(int i=0; i<books.size(); i++) {
			sum += books.get(i).getPrice();
		}
		return sum;
	}

	@Override
	public int searchAvg() {
		int avg = searchSum() / books.size();
		
		return avg;
	}
	
	
}
