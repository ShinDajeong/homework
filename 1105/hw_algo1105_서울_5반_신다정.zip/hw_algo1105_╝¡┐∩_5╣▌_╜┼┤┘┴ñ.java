package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class swea_1868_파핑파핑지뢰찾기 {
	private static int testCase, result[];
	private static int N;
	private static char map[][];
	private static boolean check[][];
	private static int dir[][] = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 0}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};
	
	static class Point {
		int x, y;

		public Point(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		testCase = Integer.parseInt(br.readLine().trim());
		result = new int[testCase + 1];
		
		for (int tc = 1; tc <= testCase; tc++) {
			N = Integer.parseInt(br.readLine().trim());
			map = new char[N][];
			check = new boolean[N][N];
			
			for (int i = 0; i < N; i++)
				map[i] = br.readLine().toCharArray();
			
			for (int i = 0; i < N; i++)
				for (int j = 0; j < N; j++)
					if (!check[i][j] && isZero(i, j)) {
						
						Queue<Point> q = new LinkedList<>();
						q.offer(new Point(i, j));
						check[i][j] = true;
						result[tc]++;
						
						while (!q.isEmpty()) {
							Point p = q.poll();
							
							if (isZero(p.x, p.y)) {
								for (int d = 0; d < dir.length; d++) {
									int ni = p.x + dir[d][0];
									int nj = p.y + dir[d][1];
									
									if (ni < 0 || ni >= N || nj < 0 || nj >= N)
										continue;
									
									if (!check[ni][nj]) {
										q.offer(new Point(ni, nj));
										check[ni][nj] = true;
									}
								}
							}
						}
					}
			
			for (int i = 0; i < N; i++)
				for (int j = 0; j < N; j++)
					if (check[i][j] == false && map[i][j] == '.')
						result[tc]++;
		}
		
		for (int tc = 1; tc <= testCase; tc++)
			System.out.println("#" + tc + " " + result[tc]);
	}
	
	private static boolean isZero(int i, int j) {
		for (int d = 0; d < dir.length; d++) {
			int nx = i + dir[d][0];
			int ny = j + dir[d][1];
			
			if (nx < 0 || ny >= N || nx < 0 || ny >= N)
				continue;
			
			if (map[nx][ny] != '.')
				return false;
		}
		
		return true;
	}

	
}
