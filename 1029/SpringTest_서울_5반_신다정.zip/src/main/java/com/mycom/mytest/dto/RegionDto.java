package com.mycom.mytest.dto;

public class RegionDto {
	private String rcode;
	private String rname;
	
	public RegionDto() {
	}

	public RegionDto(String rcode, String rname) {
		super();
		this.rcode = rcode;
		this.rname = rname;
	}
	

	public String getRcode() {
		return rcode;
	}

	public void setRcode(String rcode) {
		this.rcode = rcode;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}

	@Override
	public String toString() {
		return "RegionDto [rcode=" + rcode + ", rname=" + rname + "]";
	}
	
	
}
