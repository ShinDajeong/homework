package com.mycom.mytest.dao;

import java.util.Map;

import com.mycom.mytest.dto.UserDto;

public interface DBDao {
	public UserDto userLogin(Map<String, String> map);
	
}
