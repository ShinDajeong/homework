package com.mycom.mytest.service;

import java.util.Map;

import com.mycom.mytest.dto.UserDto;

public interface DBService {
	public UserDto userLogin(Map<String, String> map);
}
