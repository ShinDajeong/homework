package com.mycom.mytest.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.mycom.mytest.dto.CountryStatusDto;
import com.mycom.mytest.dto.GuestBookDto;


public interface GuestBookDao {

	public void writeArticle(CountryStatusDto countryStatusDto) throws SQLException;
	public List<CountryStatusDto> listArticle(Map<String, String> map) throws SQLException;
	public int getTotalCount(Map<String, String> map) throws SQLException;
	
	public GuestBookDto getArticle(int articleno) throws SQLException;
	public void modifyArticle(GuestBookDto guestBookDto) throws SQLException;
	public void deleteArticle(int articleno) throws SQLException;
	public CountryStatusDto detail(String ccode);
	
}
