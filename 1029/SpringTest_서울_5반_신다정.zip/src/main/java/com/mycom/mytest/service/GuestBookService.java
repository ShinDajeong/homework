package com.mycom.mytest.service;

import java.util.List;
import java.util.Map;

import com.mycom.mytest.dto.CountryStatusDto;
import com.mycom.mytest.dto.GuestBookDto;
import com.mycom.util.PageNavigation;


public interface GuestBookService {

	public void writeArticle(CountryStatusDto countryStatusDto) throws Exception;
	public List<CountryStatusDto> listArticle(Map<String, String> map) throws Exception;
	public PageNavigation makePageNavigation(Map<String, String> map) throws Exception;
	
	public GuestBookDto getArticle(int articleno) throws Exception;
	public void modifyArticle(GuestBookDto guestBookDto) throws Exception;
	public void deleteArticle(int articleno) throws Exception;
	public CountryStatusDto detail(String ccode);
	
}
