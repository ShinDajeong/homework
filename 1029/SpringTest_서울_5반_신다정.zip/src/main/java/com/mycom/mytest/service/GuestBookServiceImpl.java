package com.mycom.mytest.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.mytest.dao.GuestBookDao;
import com.mycom.mytest.dto.CountryStatusDto;
import com.mycom.mytest.dto.GuestBookDto;
import com.mycom.util.PageNavigation;


@Service
public class GuestBookServiceImpl implements GuestBookService {
	
	@Autowired
	private GuestBookDao guestBookDao;

	@Override
	public void writeArticle(CountryStatusDto countryStatusDto) throws Exception {
		if(countryStatusDto.getCcode() == null || countryStatusDto.getCname() == null
				|| countryStatusDto.getPatient() < 0 || countryStatusDto.getRcode() == null) {
			throw new Exception();
		}
		guestBookDao.writeArticle(countryStatusDto);
	}

	@Override
	public List<CountryStatusDto> listArticle(Map<String, String> map) throws Exception {
		map.put("key", map.get("key") == null ? "" : map.get("key"));
		map.put("word", map.get("word") == null ? "" : map.get("word"));
		return guestBookDao.listArticle(map);
	}

	@Override
	public PageNavigation makePageNavigation(Map<String, String> map) throws Exception {
		int naviSize = 10;
		int currentPage = Integer.parseInt(map.get("pg"));
		int sizePerPage = Integer.parseInt(map.get("spp"));
		PageNavigation pageNavigation = new PageNavigation();
		pageNavigation.setCurrentPage(currentPage);
		pageNavigation.setNaviSize(naviSize);
		int totalCount = guestBookDao.getTotalCount(map);
		pageNavigation.setTotalCount(totalCount);
		int totalPageCount = (totalCount - 1) / sizePerPage + 1;
		pageNavigation.setTotalPageCount(totalPageCount);
		boolean startRange = currentPage <= naviSize;
		pageNavigation.setStartRange(startRange);
		boolean endRange = (totalPageCount - 1) / naviSize * naviSize < currentPage;
		pageNavigation.setEndRange(endRange);
		pageNavigation.makeNavigator();
		return pageNavigation;
	}

	@Override
	public GuestBookDto getArticle(int articleno) throws Exception {
		return guestBookDao.getArticle(articleno);
	}

	@Override
	public void modifyArticle(GuestBookDto guestBookDto) throws Exception {
		guestBookDao.modifyArticle(guestBookDto);
	}

	@Override
	public void deleteArticle(int articleno) throws Exception {
		guestBookDao.deleteArticle(articleno);
	}

	@Override
	public CountryStatusDto detail(String ccode) {
		return guestBookDao.detail(ccode);
	}

}
