package com.mycom.mytest.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.mytest.dao.DBDao;
import com.mycom.mytest.dto.UserDto;
@Service
public class DBServiceImpl implements DBService{
	@Autowired
	private DBDao dao;
	
	@Override
	public UserDto userLogin(Map<String, String> map) {
		if(map.get("userid") == null || map.get("userpwd") == null)
			return null;
		return dao.userLogin(map);
	}

}
