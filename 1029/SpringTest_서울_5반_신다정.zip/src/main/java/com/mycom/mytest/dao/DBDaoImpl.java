package com.mycom.mytest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mycom.mytest.dto.UserDto;

@Repository
public class DBDaoImpl implements DBDao{
	
	
	@Autowired
	private DataSource dataSource;
	
	@Override
	public UserDto userLogin(Map<String, String> map) {
		
		UserDto userDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select id, pw \n");
			sql.append("from userinfo \n");
			sql.append("where id = ? and pw = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, map.get("userid"));
			pstmt.setString(2, map.get("userpwd"));
			rs = pstmt.executeQuery();
			if(rs.next()) {
				userDto = new UserDto();
				userDto.setUserId(rs.getString("id"));
				userDto.setUserPassword(rs.getString("pw"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			userDto = null;
		} finally {
			try {
	            if(rs != null ) { rs.close(); }
	            if(pstmt != null ) { pstmt.close(); }
	            if(conn != null ) { conn.close(); }
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
		}
		return userDto;
	}
	
	

}
