package com.ssafy;

import java.util.Arrays;

public class ProductMgr {
	private Product[] products = new Product[100];
	private int index=0;
	private static ProductMgr instance = new ProductMgr();
	private ProductMgr() {
		
	}
	public static ProductMgr getInstance() {
		return instance;
	}
	
	public void add(Product p) {
		products[index++] = p;
	}
	
	public void list() {
		Product[] p = new Product[index];
		
		for(int i=0; i<index; i++) {
			p[i] = products[i];
			System.out.println(p[i]);
		}
	}
	
	public void list(int num) {
		Product[] p = new Product[index];
		
		for(int i=0; i<index; i++) {
			if(products[i].getNum() == num) {
				p[i] = products[i];
				System.out.println(p[i]);
			}
		}
		
	}
	
	public void delete(int num) {
		Product[] p = new Product[index];
		
		int cnt = 0;
		for (int i = 0; i < index; i++) {
			if(products[i].getNum() != num) {
				p[cnt++] = products[i];
			}
		}

		products = p;
		index = cnt;
	}
	
	public void priceList(int price) {
		Product[] p = new Product[index];
		
		int cnt=0;
		for(int i=0; i<index; i++) {
			if(products[i].getPrice() < price) {
				p[cnt++] = products[i];
			}
		}
		
		for(int i=0; i<cnt; i++) {
			System.out.println(p[i]);
		}
	}
	
	public int getIndex(int index) {
		return index;
	}
	
}
