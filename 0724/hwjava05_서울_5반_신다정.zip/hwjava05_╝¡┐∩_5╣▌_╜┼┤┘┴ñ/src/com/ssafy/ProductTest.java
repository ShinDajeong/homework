package com.ssafy;

import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) {
		ProductMgr p = ProductMgr.getInstance();
		
		String name;
		int num, price, amount;
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("1. 상품정보 저장\n"
					+ "2. 상품리스트 전체 검색\n"
					+ "3. 상품 번호로 검색\n"
					+ "4. 상품 번호로 삭제\n"
					+ "5. 특정 가격 이하 상품 검색\n"
					+ "0. 종료");
			System.out.print("메뉴 입력 : ");
			int menu = Integer.parseInt(sc.nextLine());
			
			switch (menu) {
			case 1:
				System.out.print("상품번호 : ");
				num = Integer.parseInt(sc.nextLine());
				System.out.print("상품이름 : ");
				name = sc.nextLine();
				System.out.print("가격 : ");
				price = Integer.parseInt(sc.nextLine());
				System.out.print("수량 : ");
				amount = Integer.parseInt(sc.nextLine());
				Product pro = new Product(num, name, price, amount);
				p.add(pro);
				break;
				
			case 2:
				p.list();
				break;
				
			case 3:
				System.out.println("상품 번호로 검색 : ");
				num = Integer.parseInt(sc.nextLine());
				p.list(num);
				break;
	
			case 4:
				System.out.println("상품 번호로 삭제 : ");
				num = Integer.parseInt(sc.nextLine());
				p.delete(num);
				break;
	
			case 5:
				System.out.println("특정가격 이하의 상품만 검색 : ");
				price = Integer.parseInt(sc.nextLine());
				p.priceList(price);
				break;

			default:
				System.out.println("프로그램 종료");
				return;
			}
		}
		
	}

}
