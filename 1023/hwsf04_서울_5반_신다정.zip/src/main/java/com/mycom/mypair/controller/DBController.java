package com.mycom.mypair.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mycom.mypair.dto.MemberDto;
import com.mycom.mypair.service.DBService;

@Controller
public class DBController {
	
	@Autowired
	DBService service;
	
	@GetMapping(value="/memberDetail/{member_id}")
	@ResponseBody
	public MemberDto memberDetail(@PathVariable int member_id) {
		System.out.println(member_id);
		MemberDto memberDto = service.memberDetail(member_id);
		return memberDto;
	}
	
	@GetMapping(value="/memberList")
	@ResponseBody
	public List<MemberDto> memberList(){
		List<MemberDto> list = service.memberList();
		return list;
	}
	
	@PostMapping(value="/memberInsert")
	@ResponseBody
	public int memberInsert(MemberDto memberDto){
		System.out.println(memberDto);
		int ret = service.memberInsert(memberDto);
		return ret;
	}
	
	@PostMapping(value="/memberUpdate")
	@ResponseBody
	public int memberUpdate(MemberDto memberDto){
		System.out.println(memberDto);
		int ret = service.memberUpdate(memberDto);
		return ret;
	}
	
	@PostMapping(value="/memberDelete")
	@ResponseBody
	public int memberDetele(int member_id){
		int ret = service.memberDelete(member_id);
		return ret;
	}
	
	@PostMapping(value="/memberInsertJSON")
	@ResponseBody
	public int memberInsertJSON(@RequestBody MemberDto memberDto){
		System.out.println(memberDto);
		int ret = service.memberInsert(memberDto);
		return ret;
	}
	
	@GetMapping(value="/memberDetailNormal/{member_id}")
    //@ResponseBody
    public String empDetailNormal(@PathVariable int member_id, Model model) { //jsp로 가려면 문자열을 리턴하자
        System.out.println(member_id);
        MemberDto memberDto = service.memberDetail(member_id);
        model.addAttribute("memberDto", memberDto);
        return "detail";
    }
	
}
