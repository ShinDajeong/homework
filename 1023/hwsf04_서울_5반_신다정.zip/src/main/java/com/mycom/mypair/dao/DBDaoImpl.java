package com.mycom.mypair.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mycom.mypair.dto.MemberDto;

@Repository
public class DBDaoImpl implements DBDao {

	@Autowired
	DataSource dataSource;
	
	@Override
	public MemberDto memberDetail(int member_id) {
		 Connection con = null;
		    PreparedStatement pstmt = null;
		    ResultSet rs = null;
		
		    MemberDto dto = null;
		
		    try {
		        con = dataSource.getConnection();
		
		        StringBuilder sb = new StringBuilder();
		        sb.append("select member_id, name, major, phone_number, hobby ");
		        sb.append(" from member ");
		        sb.append(" where member_id = ? ");
		
		        pstmt = con.prepareStatement(sb.toString());
		        pstmt.setInt(1, member_id);
		
		        rs = pstmt.executeQuery();
		
		        if (rs.next()) {
		            dto = new MemberDto();
		            dto.setMember_id(rs.getInt("member_id"));
		            dto.setName(rs.getString("name"));
		            dto.setMajor(rs.getString("major"));
		            dto.setPhone_number(rs.getString("phone_number"));
		            dto.setHobby(rs.getString("hobby"));
		        }
		
		    } catch (SQLException e) {
		        e.printStackTrace();
		    } finally {
		        try {
		            if(rs != null ) { rs.close(); }
		            if(pstmt != null ) { pstmt.close(); }
		            if(con != null ) { con.close(); }
		        }catch(Exception e) {
		            e.printStackTrace();
		        }
		    }
		
		    return dto;
	}

	@Override
	public List<MemberDto> memberList() {
		Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	    List<MemberDto> list = new ArrayList<MemberDto>();
	    
	    try {
	        con = dataSource.getConnection();
	  
	        StringBuilder sb = new StringBuilder();
	        sb.append("select member_id, name, major, phone_number, hobby ");
	        sb.append(" from member");
	
	        pstmt = con.prepareStatement(sb.toString());
	
	        rs = pstmt.executeQuery();
	
	        while (rs.next()) {
	        	MemberDto dto = new MemberDto();
	            dto.setMember_id(rs.getInt("member_id"));
	            dto.setName(rs.getString("name"));
	            dto.setMajor(rs.getString("major"));
	            dto.setPhone_number(rs.getString("phone_number"));
	            dto.setHobby(rs.getString("hobby"));
	            list.add(dto);
	        }
	
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if(rs != null ) { rs.close(); }
	            if(pstmt != null ) { pstmt.close(); }
	            if(con != null ) { con.close(); }
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	    
	    return list;
	}

	@Override
	public int memberInsert(MemberDto dto) {
		Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	   int ret = -1;
		
	    try {
	        con = dataSource.getConnection();
	
	        StringBuilder sb = new StringBuilder();
	        sb.append("insert into member ( member_id, name, major, phone_number, hobby ) ");
	        sb.append(" values ( ?, ?, ?, ?, ? ) ");
	
	        pstmt = con.prepareStatement(sb.toString());
	        pstmt.setInt(1, dto.getMember_id());
	        pstmt.setString(2, dto.getName());
	        pstmt.setString(3, dto.getMajor());
	        pstmt.setString(4, dto.getPhone_number());
	        pstmt.setString(5, dto.getHobby());
	
	        ret = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if(rs != null ) { rs.close(); }
	            if(pstmt != null ) { pstmt.close(); }
	            if(con != null ) { con.close(); }
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	
	    return ret;
	}

	@Override
	public int memberUpdate(MemberDto dto) {
		Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	   int ret = -1;
		
	    try {
	        con = dataSource.getConnection();
	
	        StringBuilder sb = new StringBuilder();
	        sb.append("update member set ");
	        sb.append(" name = ?, major = ?, phone_number = ?, hobby = ? ");
	        sb.append(" where member_id = ? ");
	
	        pstmt = con.prepareStatement(sb.toString());
	        pstmt.setString(1, dto.getName());
	        pstmt.setString(2, dto.getMajor());
	        pstmt.setString(3, dto.getPhone_number());
	        pstmt.setString(4, dto.getHobby());
	        pstmt.setInt(5, dto.getMember_id());
	        ret = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if(rs != null ) { rs.close(); }
	            if(pstmt != null ) { pstmt.close(); }
	            if(con != null ) { con.close(); }
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	
	    return ret;
	}

	@Override
	public int memberDelete(int member_id) {
		Connection con = null;
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
	    
	   int ret = -1;
		
	    try {
	        con = dataSource.getConnection();
	
	        StringBuilder sb = new StringBuilder();
	        sb.append("delete from member where member_id = ? ");
	
	        pstmt = con.prepareStatement(sb.toString());
	        pstmt.setInt(1, member_id);
	        ret = pstmt.executeUpdate();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if(rs != null ) { rs.close(); }
	            if(pstmt != null ) { pstmt.close(); }
	            if(con != null ) { con.close(); }
	        }catch(Exception e) {
	            e.printStackTrace();
	        }
	    }
	
	    return ret;
	}

}
