package com.mycom.mypair.dto;

public class MemberDto {
	private int member_id;
	private String name;
	private String major;
	private String phone_number;
	private String hobby;
	
	public MemberDto() {
	}

	public MemberDto(int member_id, String name, String major, String phone_number, String hobby) {
		super();
		this.member_id = member_id;
		this.name = name;
		this.major = major;
		this.phone_number = phone_number;
		this.hobby = hobby;
	}

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}
	
	
	
}
