package com.mycom.mypair.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycom.mypair.dao.DBDao;
import com.mycom.mypair.dto.MemberDto;

@Service
public class DBServiceImpl implements DBService{
	@Autowired
	DBDao dao;

	@Override
	public MemberDto memberDetail(int member_id) {
		return dao.memberDetail(member_id);
	}

	@Override
	public List<MemberDto> memberList() {
		return dao.memberList();
	}

	@Override
	public int memberInsert(MemberDto dto) {
		return dao.memberInsert(dto);
	}

	@Override
	public int memberUpdate(MemberDto dto) {
		return dao.memberUpdate(dto);
	}

	@Override
	public int memberDelete(int member_id) {
		return dao.memberDelete(member_id);
	}
	
	
}
