package com.mycom.mypair.dao;

import java.util.List;

import com.mycom.mypair.dto.MemberDto;

public interface DBDao {
	public MemberDto memberDetail(int member_id);
	public List<MemberDto> memberList();
	public int memberInsert(MemberDto dto);
	public int memberUpdate(MemberDto dto);
	public int memberDelete(int member_id);
}
