package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		int radius = 5;
		float pi = 3.14f;
		
		System.out.println("반지름이 " + radius + "인 원의 넓이는 " + pi * radius * radius + "Cm2입니다.");
	}

}
