package com.ssafy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_2578_빙고 {

	static int[][] arr;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		arr = new int[5][5];
		
		int[] num = new int[25];
		
		for(int i=0; i<5; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			for(int j=0; j<5; j++) {
				arr[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		
		int idx = 0;
		for(int i=0; i<5; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			for(int j=0; j<5; j++)
				num[idx++] = Integer.parseInt(st.nextToken());
		}
		
		
		idx = 0;
		Outer : for(idx=0; idx<25; idx++) {
		
			for(int i=0; i<5; i++) {
				for(int j=0; j<5; j++) {
					if(num[idx] == arr[i][j]) {
						arr[i][j] = 0;
						if(isBingo(arr)) {
							System.out.println(idx+1);
							break Outer;
						}
					}
					
					
				}
			}
			
		}

	}
	private static boolean isBingo(int[][] arr) {
		int cnt = 0;
		if(arr[0][0] == 0 && arr[1][1] == 0 && arr[2][2] == 0 && arr[3][3] == 0 && arr[4][4] == 0)
			cnt++;
		if(arr[0][4] == 0 && arr[1][3] == 0 && arr[2][2] == 0 && arr[3][1] == 0 && arr[4][0] == 0)
			cnt++;
		
		// 가로 체크
		for(int i=0; i<5; i++) {
			int check = 0;
			for(int j=0; j<5; j++) {
				if(arr[i][j] == 0) {
					check++;
				}
			}
			if(check == 5)
				cnt++;
		}
		
		// 세로 체크
		for(int i=0; i<5; i++) {
			int check = 0;
			for(int j=0; j<5; j++) {
				if(arr[j][i] == 0) {
					check++;
				}
			}
			if(check == 5)
				cnt++;
		}
		
		
		if(cnt >=3)
			return true;
		else
			return false;
	}
	

}
