package com.ssafy;

import java.util.ArrayList;
import java.util.Scanner;

public class BOJ_2605_줄세우기 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		
		ArrayList<Integer> list = new ArrayList<>();
		
		for(int i=1; i<=N; i++) {
			list.add(list.size() - sc.nextInt(), i);
		}

		for(int i=0; i<list.size(); i++)
			System.out.print(list.get(i)+ " ");
	}

}
