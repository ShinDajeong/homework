package project1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BOJ_10157_자리배정 {

	static int[] dx = {0, 1, 0, -1};
	static int[] dy = {1, 0, -1, 0};
	static int nx, ny;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine());
		
		int w = Integer.parseInt(st.nextToken());
		int h = Integer.parseInt(st.nextToken());
		int num = Integer.parseInt(br.readLine());
		
		boolean[][] visited = new boolean[w+1][h+1];
		int x = 1;
		int y = 0;
		
		if(num > w * h) System.out.println("0");
		else {
			int idx = 0;
			while(num > 0) {
				 nx = x + dx[idx];
				 ny = y + dy[idx];
				 if(nx < 1 || ny < 1 || nx > w || ny > h || visited[nx][ny]) {
					 idx++;
					 if(idx == 4) idx = 0;
					 continue;
				 }
				 
				 visited[nx][ny] = true;
				 x = nx;
				 y = ny;
				 num--;
			}
			System.out.println(nx + " " + ny);
		}
		
		
	}

}
