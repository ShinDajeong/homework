package com.ssafy.hwsf01.aspect;

import org.springframework.stereotype.Component;

@Component 
public class Logger {
	public void log() {
		System.out.println("Logger : log() is called!!");
	}
}
