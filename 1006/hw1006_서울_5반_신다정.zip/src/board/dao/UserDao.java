package board.dao;

import board.dto.UserDto;

public interface UserDao {
	public int userRegister(UserDto userDto);
}
